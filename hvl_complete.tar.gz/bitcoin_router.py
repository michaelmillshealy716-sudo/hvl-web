import socket
import json
import time
import os

def run_router():
    HOST = '127.0.0.1'
    PORT = 65432
    
    active_qty = 0
    active_entry_price = 0.0

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((HOST, PORT))
        s.listen()
        print("\n" + "="*50)
        print("[*SYSTEM] INTERACTIVE PNL ROUTER ONLINE")
        print("="*50)
        print("[*SYSTEM] Monitoring engine datastream...\n")

        while True:
            try:
                conn, addr = s.accept()
                with conn:
                    data = conn.recv(1024)
                    if not data: 
                        continue

                    payload = json.loads(data.decode('utf-8'))
                    action = payload.get("action", "UNKNOWN")

                    if action == "BUY":
                        strike = payload.get("strike", 0.0)
                        contract = payload.get("contract", "YES")
                        r_min = payload.get("range_min", 10)
                        r_max = payload.get("range_max", 65)

                        print("\n" + "🔴 "*10)
                        print(f"  🚨 ENGINE TRIGGER: BUY SIGNAL 🚨  ")
                        print(f"  ACTION: Buy {contract} on ${strike}  ")
                        print(f"  TARGET PREMIUM: .{r_min} to .{r_max}  ")
                        print("🔴 "*10)

                        title = f"🚨 QUANT: BUY {contract}!"
                        content = f"Target: ${strike} | Limit: .{r_min} to .{r_max}"
                        os.system(f"termux-notification -t '{title}' -c '{content}' --priority max --vibrate 500,500,500")
                        os.system("termux-vibrate -d 1500 -f")

                        auth = input("\nDid you manually buy on phone? (Y/N): ").strip().upper()
                        if auth == 'Y':
                            try:
                                active_qty = int(input("How many contracts did you buy?: "))
                                active_entry_price = float(input("At what EXACT fill price? (e.g. 0.45): "))
                                print(f"[OK] Position Locked. Total Cost: ${active_qty * active_entry_price:.2f}. Monitoring Trailing Highs...")
                                conn.sendall(b"CONFIRMED")
                            except ValueError:
                                print("[WARNING] Invalid numbers. Disabling local PnL math. Engine tracking blindly...")
                                active_qty = 0
                                conn.sendall(b"CONFIRMED")
                        else:
                            print("[SKIPPED] Position aborted. Returning to scan loop.")
                            conn.sendall(b"REJECTED")

                    elif action == "SELL":
                        strike = payload.get("strike", 0.0)
                        contract = payload.get("contract", "UNKNOWN")
                        reason = payload.get("reason", "Trailing Stop Hit")

                        print("\n" + "🟢 "*10)
                        print(f"  💰 INITIATE LIQUIDATION PROTOCOL 💰  ")
                        print(f"  POSITION: Dump {contract} Contracts  ")
                        print(f"  REASON: {reason}  ")
                        print("🟢 "*10)

                        title = f"💰 QUANT: SELL {contract} NOW!"
                        os.system(f"termux-notification -t '{title}' -c '{reason}' --priority max --vibrate 1000,200,1000")
                        os.system("termux-vibrate -d 1500 -f")

                        auth = input("\nDid you manually sell on phone? (Y/N): ").strip().upper()
                        if auth == 'Y':
                            if active_qty > 0:
                                try:
                                    exit_price = float(input("At what EXACT fill price? (e.g. 0.85): "))
                                    pnl = (exit_price - active_entry_price) * active_qty
                                    if pnl >= 0:
                                        print(f"\n[WIN] Trade executed flawlessly. You made +${pnl:.2f} 💸")
                                    else:
                                        print(f"\n[LOSS] Trade liquidated. You lost -${abs(pnl):.2f} 🩸")
                                except ValueError:
                                    print("[WARNING] Invalid math input. Skipping PnL log.")
                                    
                            print("[OK] Resetting kinematics to OBSERVING mode...\n")
                            active_qty = 0
                            active_entry_price = 0.0
                            conn.sendall(b"CONFIRMED")
                        else:
                            print("[WARNING] Override detected. You will bleed. Re-ping scheduled.")
                            conn.sendall(b"REJECTED")

            except json.JSONDecodeError:
                print("[ERROR] Corrupted JSON payload received.")
            except Exception as e:
                print(f"[ERROR] Router fault: {e}")
                time.sleep(1)

if __name__ == "__main__": run_router()
