# =============================================================================
# (c) 2026 HEALY VECTOR LABS. ALL RIGHTS RESERVED.
# This source code is the proprietary property of Michael Healy.
# Unauthorized reproduction, distribution, or reverse-engineering is strictly
# prohibited. This file is part of the VERITAS Auditor / FASE Engine.
# =============================================================================

import sys, os, time
from datetime import datetime
import yfinance as yf
import robin_stocks.robinhood as rh

WATCHLIST = ["MO", "XYZ", "GPRO", "BBBY", "PINS", "SNAP", "WDC", "MDB", "AMC", "GME", "SPCE", "WTI", "PLTR", "TSLA", "PTON", "SOFI", "MSTR", "ROKU", "RIVN", "MARA", "RIOT", "CVNA", "UPST", "PLUG", "FUBO", "AFRM", "XYZ", "ABNB"]
ACTIVE_TRADES = {}
HISTORY = {ticker: {"prices": [], "hunk_score": None} for ticker in WATCHLIST}

class C:
    G, R, Y, BBLD, END = '\033[92m', '\033[91m', '\033[93m', '\033[1;94m', '\033[0m'

def get_hunk_score(ticker):
    if HISTORY[ticker]["hunk_score"] is not None: return HISTORY[ticker]["hunk_score"]
    try:
        t_obj = yf.Ticker(ticker)
        info = t_obj.info
        sf = info.get("shortPercentOfFloat", 0) or 0
        if sf == 1: sf = 100
        score = (sf * 0.7) + ((info.get("shortRatio", 0) or 0) * 0.3)
        HISTORY[ticker]["hunk_score"] = score
        return score
    except: return 0

def find_quality_contract(ticker, side):
    try:
        chain = rh.options.find_options_by_expiration(ticker, expirationDate='2026-05-15', optionType=side)
        valid = [o for o in chain if 0.35 <= float(o['mark_price']) <= 0.60]
        if not valid: return None
        valid.sort(key=lambda x: float(x.get('volume', 0) or 0), reverse=True)
        return valid[0]
    except: return None
def hunk_dump_execution():
    print(f"\r{C.BBLD}[*] VERITAS STANDBY @ {datetime.now().strftime('%H:%M:%S')}{C.END}   ", end="", flush=True)
    old_stderr = sys.stderr
    sys.stderr = open(os.devnull, 'w')
    try:
        quotes = rh.stocks.get_quotes(WATCHLIST)
        quotes_data = {q['symbol']: q for q in quotes if q is not None}
    except Exception:
        sys.stderr = old_stderr
        return
    finally:
        sys.stderr = old_stderr
    for ticker in WATCHLIST:
        if ticker in ACTIVE_TRADES: continue
        quote = quotes_data.get(ticker)
        if not quote: continue
        curr = float(quote['last_trade_price'])
        hunk = get_hunk_score(ticker)
        prices = HISTORY[ticker]["prices"]
        prices.append(curr)
        if len(prices) > 3: prices.pop(0)
        if len(prices) == 3 and hunk > 10:
            acc = (prices[-1] - prices[-2]) - (prices[-2] - prices[-3])
            acc_t = 0.08 if ticker in ["GME", "AMC"] else 0.05
            target = None
            if acc > acc_t: target = find_quality_contract(ticker, 'call')
            elif acc < -acc_t: target = find_quality_contract(ticker, 'put')
            if target:
                print(f"\n{C.G}[EXEC] {ticker} {target['strike_price']} {target['type']}{C.END}")
                ACTIVE_TRADES[ticker] = True
                return

if __name__ == "__main__":
    rh.login(username='Michaelmillshealy716@gmail.com', password='M3141592654h*!*$$', expiresIn=86400, scope='internal', store_session=True)
    p = rh.profiles.load_account_profile()
    print(f"\n{C.G}[+] VERITAS INITIALIZED. LIQUIDITY: ${p['buying_power']}{C.END}")
    while True:
        try:
            hunk_dump_execution()
            time.sleep(1)
        except KeyboardInterrupt: break

