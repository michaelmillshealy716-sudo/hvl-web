import os
import sys
import time
import math
from datetime import datetime
import numpy as np
from google import genai
from google.genai import types
import robin_stocks.robinhood as r

# ==============================================================================
# Environment and Library Handshake
# ==============================================================================
api_key = os.getenv("GEMINI_API_KEY")
if not api_key:
    print("[X] Critical Error: GEMINI_API_KEY missing from .env file.")
    sys.exit(1)

# Initialize the paid API pipeline client node
client = genai.Client(api_key=api_key)

# Persistent global buffer array to hold real market data tuples: (time, spot)
price_history = []

def run_local_kinematics(current_spot, dt_step=2.0):
    """
    KINETICS LAYER: Computes localized velocity and acceleration 
    via historical time/price steps to output a 3rd-order Taylor Series target.
    """
    global price_history
    current_time = time.time()
    price_history.append((current_time, current_spot))
    
    # Maintain rolling lookback window constraint
    if len(price_history) > 5:
        price_history.pop(0)
        
    if len(price_history) < 4:
        return 0.0, 0.0, current_spot

    # Extract historical tracking states directly out of the data matrices
    t3, p3 = price_history[-1]
    t2, p2 = price_history[-2]
    t1, p1 = price_history[-3]
    t0, p0 = price_history[-4]

    dt1, dt0 = t2 - t1, t1 - t0
    if dt1 <= 0 or dt0 <= 0:
        return 0.0, 0.0, current_spot

    # Map state derivatives
    v1 = (p2 - p1) / dt1
    v0 = (p1 - p0) / dt0
    accel = (v1 - v0) / (0.5 * (t2 - t0))
    
    # Project forward assuming constant step interval duration
    projected_target = current_spot + (v1 * dt_step) + (0.5 * accel * (dt_step ** 2))
    return v1, accel, projected_target

def call_studio_intelligence(spot, vel, accel, target):
    """
    TELEMETRY ROUTER: Ships real kinematics values to your paid tier 
    endpoint to get an institutional-grade signal back.
    """
    model_id = "gemini-2.5-flash"  # Verified model targeting structure
    
    system_instruction = (
        "You are an advanced quantitative layer. Analyze the incoming Taylor-series variables "
        "and return a volatility-normalized energy signal between -1.00 and +1.00. Output ONLY the float."
    )
    
    prompt = f"""
    [TICK METRICS]
    Spot Price: ${spot:.2f}
    Velocity (P'): {vel:.2f}
    Acceleration (P''): {accel:.2f}
    Taylor Target Projection: ${target:.2f}
    """
    
    try:
        response = client.models.generate_content(
            model=model_id,
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=system_instruction,
                temperature=0.1,
                max_output_tokens=10
            )
        )
        return response.text.strip()
    except Exception as e:
        return "API_ERR"

def get_live_tape_price():
    """
    PRODUCTION TICKER: Polls the live, active market spot price 
    directly from your authenticated Robinhood Crypto node.
    """
    try:
        quote = r.crypto.get_crypto_quote('BTC')
        if quote and 'mark_price' in quote:
            return float(quote['mark_price'])
    except Exception as e:
        # Prevent loop fragmentation on minor websocket dropped frames
        pass
    return None

# ==============================================================================
# MAIN EXECUTION ROUTINE
# ==============================================================================
if __name__ == "__main__":
    # Pull exchange credentials out of your environment layers
    rh_user = os.getenv("RH_USERNAME")
    rh_pass = os.getenv("RH_PASSWORD")
    
    print("\n" + "="*75)
    print(" HEALY VECTOR LABS - UNIFIED PRODUCTION LOG (LIVE BTC FEED)")
    print("="*75)
    print(f"{'TIMESTAMP':<10} | {'LIVE SPOT':<9} | {'TAYLOR TGT':<10} | {'VOLTAGE SIGNAL (API)'}")
    print("-"*75)

    # Initialize connection to the exchange broker infrastructure
    try:
        r.login(username=rh_user, password=rh_pass)
    except Exception as e:
        print(f"[X] Exchange Authentication Panic: {e}")
        sys.exit(1)

    try:
        while True:
            spot_price = get_live_tape_price()
            
            if spot_price is None:
                time.sleep(1.0)
                continue
                
            timestamp = datetime.now().strftime("%H:%M:%S")
            
            # Execute your exact local tracking calculations
            v, a, target = run_local_kinematics(spot_price, dt_step=5.0)
            
            if len(price_history) >= 4:
                # Pipe kinematic variables straight out to the server framework
                api_energy_signal = call_studio_intelligence(spot_price, v, a, target)
                print(f"{timestamp:<10} | ${spot_price:<8.2f} | ${target:<9.2f} | {api_energy_signal}")
            else:
                print(f"{timestamp:<10} | ${spot_price:<8.2f} | [WARMING UP DATA BUFFER {len(price_history)}/4]")
                
            # Loop delay matching your original script runtime execution matrix
            time.sleep(2.0)
            
    except KeyboardInterrupt:
        print("\n[*] Core System Halted Cleanly.")

