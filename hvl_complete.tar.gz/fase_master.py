# =============================================================================
# (c) 2026 HEALY VECTOR LABS. ALL RIGHTS RESERVED.
# This source code is the proprietary property of Michael Healy.
# Unauthorized reproduction, distribution, or reverse-engineering is strictly
# prohibited. This file is part of the VERITAS Auditor / FASE Engine.
# =============================================================================

import json
import subprocess
import time
import sys
import os
import numpy as np
import robin_stocks.robinhood as rh
from datetime import datetime
import logging

# Kill API noise
logging.getLogger("urllib3").setLevel(logging.CRITICAL)

class C:
    G = "\033[92m"
    R = "\033[91m"
    Y = "\033[93m"
    B = "\033[94m"
    CYAN = "\033[96m"
    M = "\033[35m"
    BBLD = "\033[1m"
    END = "\033[0m"

MAX_BULLETS = 3
ACTIVE_TRADES = {}

# [✔] FULL MATRIX REPLICATED EXACTLY
STOCKS = [
    "AAPL", "MSFT", "GOOGL", "AMZN", "META", "TSLA", "NVDA", "AMD", 
    "SPY", "QQQ", "IWM", "DIA", "VXX", "UVXY", "SQQQ", "TQQQ", "SOXX", "SOXL",
    "INTC", "TSM", "AVGO", "QCOM", "MU", "TXN", "AMAT", "LRCX",
    "CRM", "ADBE", "NOW", "SNOW", "PLTR", "CRWD", "PANW", 
    "JPM", "BAC", "WFC", "GS", "MS", "V", "MA", "AXP", "PYPL", "SQ", "COIN", "HOOD",
    "WMT", "TGT", "COST", "HD", "LOW", "MCD", "SBUX", "NKE", "KO", "PEP",
    "JNJ", "UNH", "PFE", "MRK", "ABBV", "LLY", "AMGN", "CVS",
    "XOM", "CVX", "COP", "OXY", "SLB", "HAL", 
    "BA", "LMT", "RTX", "NOC", "GD", "CAT", "DE",
    "DIS", "NFLX", "SPOT", "ROKU", "EA",
    "UBER", "LYFT", "DAL", "UAL", "LUV", "AAL",
    "ABNB", "BKNG", "MAR", "HLT", "CCL", "RCL", "MGM", "DKNG"
]

def rh_login():
    try:
        print(f"{C.CYAN}[*] SYSTEM PURGE: INITIATING FRESH HANDSHAKE...{C.END}")
        try:
            rh.logout() 
        except:
            pass
        
        # Hardcoded Architect Credentials
        rh.login("michaelmillshealy716@gmail.com", "M3141592654h*!*$$", expiresIn=86400, pickle_name="fasemaster")
        
        profile = rh.account.load_account_profile()
        bp = float(profile.get('buying_power', '0.00'))
        print(f"{C.G}[+] SUCCESS. FASEMASTER ACTIVE. BP: ${bp:.2f}{C.END}")
    except Exception as e:
        print(f"{C.R}[!] AUTH CRITICAL: {e}{C.END}")
        sys.exit(1)

def get_wallet():
    try:
        profile = rh.account.load_account_profile()
        return float(profile.get('buying_power', '0.00'))
    except Exception: return 0.0

def get_kinematics(prices):
    if len(prices) < 4: return 0.0, 0.0, 0.0
    p = np.array(prices[-4:], dtype=float)
    v = np.gradient(p)
    a = np.gradient(v)
    return v[-1], a[-1], p[-1]

def find_cheap_option(ticker, opt_type):
    try:
        chains = rh.options.get_chains(ticker)
        if not chains or not chains.get('expiration_dates'): return None
        valid_exp = [exp for exp in chains['expiration_dates'] if (datetime.strptime(exp, "%Y-%m-%d") - datetime.now()).days >= 2]
        if not valid_exp: return None
        valid_options = rh.options.find_options_by_expiration(ticker, expirationDate=valid_exp[0], optionType=opt_type.lower())
        valid = [o for o in valid_options if o['ask_price'] and 0.03 <= float(o['ask_price']) <= 0.20]
        if not valid: return None
        valid.sort(key=lambda x: float(x['volume'] or 0), reverse=True)
        return valid[0]
    except Exception: return None

def manage_positions():
    for ticker, data in list(ACTIVE_TRADES.items()):
        opt = data['option']
        try:
            m_data = rh.options.get_option_market_data(ticker, opt['expiration_date'], opt['strike_price'], data['type'].lower())
            info = m_data[0] if isinstance(m_data, list) else m_data
            if not info: continue
            
            cur_bid = float(info.get('bid_price', 0))
            if cur_bid == 0: continue
            
            profit = ((cur_bid - float(data['entry_premium'])) / float(data['entry_premium'])) * 100
            if profit >= 18.5:
                print(f"\n{C.G}[$$$] PROFIT CAPTURED: +{profit:.2f}% ON {ticker}{C.END}")
                rh.orders.order_sell_option_limit("close", "credit", round(cur_bid, 2), ticker, 1, opt['expiration_date'], opt['strike_price'], data['type'].lower())
                del ACTIVE_TRADES[ticker]
        except Exception: continue

def hunt_best_deal():
    cands = []
    wallet = get_wallet()
    old_stderr = sys.stderr
    sys.stderr = open(os.devnull, 'w')
    try:
        print(f"\r{C.B}[*] SCANNING {len(STOCKS)} TICKERS | BP: ${wallet:.2f}{C.END}   ", end="", flush=True)
        for t in STOCKS:
            if t in ACTIVE_TRADES: continue
            try:
                h = rh.stocks.get_stock_historicals(t, interval='5minute', span='week', bounds='regular')
                # [!] THE FIX: Skip 404s/None results without crashing
                if not h or h[0] is None: continue 
                
                px = [float(x['close_price']) for x in h if x and x['close_price']]
                if len(px) < 4: continue
                
                v, a, p = get_kinematics(px)
                cands.append({'ticker': t, 'score': a, 'v': v, 'price': px[-1]})
            except: continue
    finally: sys.stderr = old_stderr

    if not cands: return None
    mu, sigma = np.mean([c['score'] for c in cands]), np.std([c['score'] for c in cands])
    cands.sort(key=lambda x: abs((x['score'] - mu) / sigma if sigma > 0 else 0), reverse=True)
    
    for c in cands:
        z = (c['score'] - mu) / sigma if sigma > 0 else 0
        if abs(z) >= 1.84 and wallet >= 3.00:
            opt_type = 'call' if c['v'] >= 0 else 'put'
            target_opt = find_cheap_option(c['ticker'], opt_type)
            if target_opt:
                print(f"\n{C.G}{C.BBLD}[♛] ALPHA TARGET: {c['ticker']} | Z: {z:.2f}{C.END}")
                return {'ticker': c['ticker'], 'type': opt_type, 'option': target_opt}
    return None

def execute_trade(target):
    opt = target['option']
    try:
        rh.orders.order_buy_option_limit("open", "debit", opt['ask_price'], target['ticker'], 1, opt['expiration_date'], opt['strike_price'], target['type'])
        print(f"{C.G}[✔] ORDER SENT: {target['ticker']} {target['type'].upper()} @ ${opt['ask_price']}{C.END}")
        ACTIVE_TRADES[target['ticker']] = {"entry_premium": float(opt['ask_price']), "option": opt, "type": target['type']}
    except Exception as e: print(f"{C.R}[!] TRADE ERROR: {e}{C.END}")

if __name__ == "__main__":
    rh_login()
    print(f"{C.BBLD}{C.Y}[!] HEALY VECTOR LABS: FASEMASTER V2.2 ONLINE{C.END}")
    while True:
        try:
            if len(ACTIVE_TRADES) < MAX_BULLETS:
                target = hunt_best_deal()
                if target: execute_trade(target)
            manage_positions()
            time.sleep(2)
        except KeyboardInterrupt: sys.exit(0)

