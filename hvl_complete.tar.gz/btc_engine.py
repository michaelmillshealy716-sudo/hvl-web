import os, time, json, math, socket
import numpy as np
from datetime import datetime, timedelta
from dotenv import load_dotenv
import robin_stocks.robinhood as r

load_dotenv()

def authenticate_node():
    r.login(username=os.getenv("RH_USERNAME"), password=os.getenv("RH_PASSWORD"))

class NeuroKinematics:
    def __init__(self):
        self.timestamps, self.prices, self.volumes = [], [], []
        self.velocities, self.accelerations = [], []
        self.buffer_limit = 60

    def ingest_crt_tick(self, t, price, vol):
        self.timestamps.append(t); self.prices.append(price); self.volumes.append(vol)
        if len(self.prices) > 1:
            dt = self.timestamps[-1] - self.timestamps[-2]
            self.velocities.append((self.prices[-1] - self.prices[-2]) / dt if dt != 0 else 0)
        else: 
            self.velocities.append(0.0)

        if len(self.velocities) > 4:
            v_past = sum(self.velocities[-5:-1]) / 4.0
            dt = self.timestamps[-1] - self.timestamps[-5]
            self.accelerations.append((self.velocities[-1] - v_past) / dt if dt != 0 else 0)
        else: 
            self.accelerations.append(0.0)

        if len(self.prices) > self.buffer_limit:
            self.timestamps.pop(0); self.prices.pop(0); self.volumes.pop(0)
            self.velocities.pop(0); self.accelerations.pop(0)

    def get_vwma(self, period=15):
        if len(self.prices) < period: return self.prices[-1] if self.prices else 0.0
        prices_arr = np.array(self.prices[-period:])
        vols_arr = np.array(self.volumes[-period:])
        if np.sum(vols_arr) == 0: return np.mean(prices_arr) 
        return np.sum(prices_arr * vols_arr) / np.sum(vols_arr)

    def project_taylor_series(self, dt_seconds):
        if len(self.prices) < 2: return 0.0
        time_decay = max(0.1, 1.0 - (dt_seconds / 3600.0))
        return self.prices[-1] + (self.velocities[-1] * dt_seconds * time_decay)

class DerivativeManager:
    def __init__(self):
        self.active_position = False
        self.entry_strike = 0.0
        self.entry_spot_price = 0.0
        self.contract_type = ""
        self.max_profit_delta = 0.0

    def check_buy_lock(self, k, spot, projected, time_left):
        if self.active_position: 
            return False, 0.0, "", "[HOLDING]"
            
        if len(k.velocities) < 20: 
            return False, 0.0, "", "[WARMING UP BUFFER]"

        vwma = k.get_vwma(15)

        # -------------------------------------------------------------
        # KILLSWITCH 1: EXPIRATION DEATH ZONE
        # -------------------------------------------------------------
        if time_left < 300:
            return False, 0.0, "", "[DEATH ZONE] Bankroll locked. Switch to next hour."

        # -------------------------------------------------------------
        # KILLSWITCH 2: DYNAMIC LIQUIDITY LOCK (The Dead Market Filter)
        # -------------------------------------------------------------
        vol_micro = np.mean(k.volumes[-5:])
        vol_macro = np.mean(k.volumes)
        if vol_micro < (vol_macro * 0.85):
            return False, 0.0, "", "[FLATLINE] Liquidity dead. Awaiting institutional volume."
        
        v_std = np.std(k.velocities[-10:])
        vol_avg = np.mean(k.volumes[-10:])
        
        gamma_active = time_left < 1200
        grind_threshold = 25.0 if gamma_active else 40.0
        vol_req = 1.05 if gamma_active else 1.15
        
        is_god_candle_up = k.velocities[-1] > (v_std * 3.0)
        is_god_candle_down = k.velocities[-1] < -(v_std * 3.0)

        # 15-Tick Structural Baseline
        price_delta_15 = spot - k.prices[-15] 

        bull_vel = k.velocities[-1] > (v_std * 0.7)
        bull_vol = k.volumes[-1] > (vol_avg * vol_req)
        bull_grind = price_delta_15 > grind_threshold

        bear_vel = k.velocities[-1] < -(v_std * 0.7)
        bear_vol = k.volumes[-1] > (vol_avg * vol_req)
        bear_grind = price_delta_15 < -grind_threshold

        # SCRIPT 1: STRUCTURAL MOMENTUM UP (YES)
        if spot > vwma and ((bull_vol and bull_vel) or bull_grind):
            target_strike = math.ceil(spot / 100.0) * 100.0
            
            # WIDER OFFSET: Forces premium down to 20c-55c range mathematically
            if (target_strike - spot) < 25.0: target_strike += 100.0
            if is_god_candle_up: target_strike += 100.0
            
            proj_clearance = 1.0 if bull_grind else 5.0
            if projected >= (target_strike + proj_clearance):
                msg = "GOD CANDLE UP" if is_god_candle_up else "Bullish Trend Ignition"
                return True, target_strike, "YES", f"[RADAR] {msg}. TGT: {target_strike}"
                
        # SCRIPT 2: STRUCTURAL MOMENTUM DOWN (NO)
        if spot < vwma and ((bear_vol and bear_vel) or bear_grind):
            target_strike = math.floor(spot / 100.0) * 100.0
            
            # WIDER OFFSET: Prevents overpaying for deep ITM bottoms
            if (spot - target_strike) < 25.0: target_strike -= 100.0
            if is_god_candle_down: target_strike -= 100.0
            
            proj_clearance = 1.0 if bear_grind else 5.0
            if projected <= (target_strike - proj_clearance):
                msg = "GOD CANDLE DOWN" if is_god_candle_down else "Bearish Trend Ignition"
                return True, target_strike, "NO", f"[RADAR] {msg}. TGT: {target_strike}"

        status_msg = f"[OBSERVING - VANGUARD] VWMA: {vwma:.2f} | 15-Tick: {price_delta_15:.2f}"
        if gamma_active: status_msg += " | GAMMA ACTIVE"
        return False, 0.0, "", status_msg

    def check_sell_lock(self, k, spot, time_left):
        if not self.active_position: 
            return False, "[NO POS]"
            
        if self.contract_type == "YES":
            trade_delta = spot - self.entry_spot_price
            strike_distance = spot - self.entry_strike
            momentum_dead = (k.velocities[-1] < 0)
        else: 
            trade_delta = self.entry_spot_price - spot
            strike_distance = self.entry_strike - spot
            momentum_dead = (k.velocities[-1] > 0)
            
        if trade_delta > self.max_profit_delta:
            self.max_profit_delta = trade_delta
            
        pullback_from_peak = self.max_profit_delta - trade_delta
        
        price_delta_5 = spot - k.prices[-5]
        momentum_failing_macro = (self.contract_type == "YES" and price_delta_5 < 0) or (self.contract_type == "NO" and price_delta_5 > 0)
        
        # 1. SCALP PROFIT TAKE 
        if self.max_profit_delta >= 40.0:
            if pullback_from_peak >= 20.0:
                return True, f"Trailing Stop Hit. Peak was +{self.max_profit_delta:.2f} Pts. Securing profit."
                
        # 2. STRUCTURAL STOP LOSS 
        if trade_delta < -45.0 and momentum_failing_macro:
            return True, f"Trend broke. Trade dropped {trade_delta:.2f} Pts. CUT LOSSES."
            
        # 3. EXPIRATION DEATH
        if time_left < 120 and strike_distance < 15.0:
            return True, "Expiration imminent. Liquidation mandatory."
            
        return False, f"[{self.contract_type} TGT: {self.entry_strike}] PnL Delta: {trade_delta:.2f} | Peak: +{self.max_profit_delta:.2f}"

def send_signal(payload):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect(('127.0.0.1', 65432))
            s.sendall(json.dumps(payload).encode('utf-8'))
            return s.recv(1024).decode('utf-8') == "CONFIRMED"
    except: 
        return False

def run_daemon():
    authenticate_node()
    engine = NeuroKinematics()
    manager = DerivativeManager()
    print("\n[*SYSTEM] Day 3 Apex Vanguard Online. Awaiting market volume...")
    
    last_cum_vol = 0.0
    
    while True:
        try:
            quote = r.crypto.get_crypto_quote('BTC')
            if not quote or 'mark_price' not in quote:
                time.sleep(1.0)
                continue
                
            spot = float(quote['mark_price'])
            cum_vol = float(quote['volume'])
            t = time.time()
            
            tick_vol = max(0.0, cum_vol - last_cum_vol) if last_cum_vol > 0 else 1.0
            last_cum_vol = cum_vol
            
            engine.ingest_crt_tick(t, spot, tick_vol)
            
            now = datetime.now()
            next_hour = (now.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1))
            seconds_left = (next_hour - now).total_seconds()
            
            projected = engine.project_taylor_series(seconds_left)
            buffer_count = len(engine.prices)
            
            if not manager.active_position:
                buy_now, strike, contract_type, msg = manager.check_buy_lock(engine, spot, projected, seconds_left)
                print(f"[{now.strftime('%H:%M:%S')}] | BTC: {spot:<9.2f} | {buffer_count}/60 | {msg}")
                
                if buy_now:
                    # Enforcing strict premium boundaries
                    if send_signal({"action": "BUY", "contract": contract_type, "strike": strike, "range_min": 10, "range_max": 55}):
                        manager.active_position = True
                        manager.entry_strike = strike
                        manager.entry_spot_price = spot
                        manager.contract_type = contract_type
                        time.sleep(10)
            else:
                sell_now, msg = manager.check_sell_lock(engine, spot, seconds_left)
                print(f"[{now.strftime('%H:%M:%S')}] | BTC: {spot:<9.2f} | {buffer_count}/60 | {msg}")
                
                if sell_now:
                    if send_signal({"action": "SELL", "contract": manager.contract_type, "strike": manager.entry_strike, "reason": msg}):
                        manager.active_position = False
                        manager.entry_strike = 0.0
                        manager.entry_spot_price = 0.0
                        manager.contract_type = ""
                        time.sleep(10)
            
            time.sleep(5)
        except Exception as e:
            time.sleep(5)

if __name__ == "__main__":
    run_daemon()
