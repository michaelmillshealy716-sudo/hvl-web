# (C) 2026 HEALY VECTOR LABS. ALL RIGHTS RESERVED.
# ==============================================================================
import json
import time
import os
import math
import numpy as np
import yfinance as yf
import requests
from datetime import datetime
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from nhlpy import NHLClient

# --- HVL Master Aesthetics ---
C_GREEN = '\033[92m'
C_CYAN = '\033[96m'
C_RED = '\033[91m'
C_WARN = '\033[93m'
C_PURP = '\033[95m'
C_RESET = '\033[0m'
C_BOLD = '\033[1m'

# ==============================================================================
# CONFIGURATION ENVIRONMENT
# ==============================================================================
# Drop your active JSONBlob or KVDB URL right here
API_ENDPOINT = "https://jsonblob.com/api/jsonBlob/1373038692791443456"

# ==============================================================================
# FASE & VERITAS QUANTITATIVE ENGINES
# ==============================================================================
class GeopoliticalBridge:
    def __init__(self):
        self.analyzer = SentimentIntensityAnalyzer()
        
    def get_intensity_scalar(self, raw_headline):
        if not raw_headline or raw_headline == "API_THROTTLE": 
            return 0.0
        return self.analyzer.polarity_scores(raw_headline)['compound']

class EdgarRaven:
    def __init__(self):
        self.bridge = GeopoliticalBridge()
        
    def get_ticker_sentiment_and_headline(self, ticker):
        try:
            stock = yf.Ticker(ticker)
            news = stock.news
            if news and len(news) > 0:
                first_story = news[0]
                # Extract headline regardless of structural format differences in yfinance versions
                if isinstance(first_story, dict) and 'content' in first_story:
                    headline = first_story.get('content', {}).get('title', '')
                else:
                    headline = first_story.get('title', '')
                
                if headline:
                    score = self.bridge.get_intensity_scalar(headline)
                    return score, headline
            return 0.0, "Stable Vector Baseline Status"
        except Exception:
            return 0.0, "[YF LIMIT] Throttled. Maintaining drift baseline models."

class FASEStochasticEngine:
    def __init__(self, x0, T, dt):
        self.x0 = x0
        self.T = T
        self.dt = dt
        self.N = int(T / dt)
        self.t = np.linspace(0, self.T, self.N)
        
    def simulate_sentiment_path(self, base_mu, sigma, sentiment_score):
        # Shift the drift velocity based on the live VADER sentiment metric
        mu_adj = base_mu + (sentiment_score * 0.5 * base_mu)
        dW = np.random.normal(0, np.sqrt(self.dt), self.N)
        W = np.cumsum(dW)
        return self.x0 * np.exp((mu_adj - 0.5 * sigma**2) * self.t + sigma * W)

class ScoreEngine:
    def __init__(self, target_team="Buffalo Sabres", target_date="2026-05-16"):
        self.client = NHLClient()
        self.target_team = target_team
        self.target_date = target_date
        self.config = {"ROAD_BIAS": 1.15, "SIGMOID_SENSITIVITY": 0.45}

    def find_active_game(self):
        try:
            schedule_data = self.client.schedule.daily_schedule(date=self.target_date)
            for game in schedule_data.get('games', []):
                home_name = game.get('homeTeam', {}).get('name', {}).get('default', '')
                away_name = game.get('awayTeam', {}).get('name', {}).get('default', '')
                if self.target_team in [home_name, away_name]:
                    return game['id']
            return 2025030246
        except Exception:
            return 2025030246

    def get_veritas_payload(self, game_id):
        try:
            gd = self.client.game_center.boxscore(game_id=game_id)
            away = gd.get('awayTeam', {})
            home = gd.get('homeTeam', {})
            
            a_sog = float(away.get('sog', 0))
            h_sog = float(home.get('sog', 0))
            a_g = float(away.get('score', 0))
            h_g = float(home.get('score', 0))
            
            a_hits, h_hits, a_fo, h_fo = 0.0, 0.0, 50.0, 50.0
            
            for stat in gd.get('boxscore', {}).get('teamStats', []):
                cat = stat.get('category')
                raw_a = str(stat.get('awayValue', '')).replace('%','')
                raw_h = str(stat.get('homeValue', '')).replace('%','')
                try:
                    if cat == 'sog':
                        a_sog = float(raw_a) if raw_a else a_sog
                        h_sog = float(raw_h) if raw_h else h_sog
                    elif cat == 'hits':
                        a_hits = float(raw_a) if raw_a else 0.0
                        h_hits = float(raw_h) if raw_h else 0.0
                    elif cat == 'faceoffWinningPctg':
                        a_fo = float(raw_a) if raw_a else 50.0
                        h_fo = float(raw_h) if raw_h else 50.0
                except ValueError:
                    continue

            b_sv = (h_sog - h_g) / h_sog if h_sog > 0 else 0.900
            m_sv = (a_sog - a_g) / a_sog if a_sog > 0 else 0.900

            def qm(side, delta, hits, fo, opp_v, p, is_road):
                amp = 1.0 + (abs(fo - 50)/100.0) + (delta*0.5)
                m = 1.0 / (p + 0.1)
                k = (delta**2)/(2*m) if m > 0 else 0
                H = (k + opp_v + (hits*0.01)) * amp * (self.config["ROAD_BIAS"] if is_road and side=="away" else 1.0)
                psi = (1 / (1 + math.exp(-(H * self.config["SIGMOID_SENSITIVITY"])))) * 100
                return {"H": round(H, 4), "psi_sq": round(psi, 2), "strike": round(min((psi*amp), 99.99), 2)}

            mtl_q = qm("home", round(h_sog/60, 3), h_hits, h_fo, b_sv, 1.0, False)
            buf_q = qm("away", round(a_sog/60, 3), a_hits, a_fo, m_sv, 1.5, True)
            
            tot = mtl_q["H"] + buf_q["H"] + 0.1
            p1, p2 = mtl_q["H"]/tot, buf_q["H"]/tot
            ent = - (p1 * math.log(p1 + 0.01) + p2 * math.log(p2 + 0.01))
            
            return {
                "timestamp": datetime.now().strftime("%H:%M:%S"),
                "entropy": round(ent, 3),
                "MTL": mtl_q,
                "BUF": buf_q
            }
        except Exception:
            return {
                "timestamp": datetime.now().strftime("%H:%M:%S"), "entropy": 0.452,
                "MTL": {"H": 1.245, "psi_sq": 54.2, "strike": 58.4},
                "BUF": {"H": 0.982, "psi_sq": 41.8, "strike": 44.1}
            }

# ==============================================================================
# MASTER REAL-TIME DATA STREAM RUNNER
# ==============================================================================
if __name__ == "__main__":
    os.system('clear' if os.name == 'posix' else 'cls')
    print(f"{C_CYAN}[SYSTEM] Launching High-Frequency Healy Vector Labs Core Daemon...{C_RESET}")
    
    edgar = EdgarRaven()
    nhl_engine = ScoreEngine()
    
    tickers = ["TSLA", "F", "XOM", "PFE", "CL=F"]
    base_prices = {"TSLA": 175.50, "F": 12.30, "XOM": 118.20, "PFE": 28.40, "CL=F": 82.10}
    
    cycle = 0
    fase_cache = {}
    
    try:
        while True:
            # 1. Gather Calculations from VERITAS Engine
            game_id = nhl_engine.find_active_game()
            v_data = nhl_engine.get_veritas_payload(game_id)
            
            # 2. Gather Calculations from FASE Engine (Every 3rd loop to protect API limits)
            if cycle % 3 == 0 or not fase_cache:
                fase_cache = {}
                print(f"{C_PURP}[FASE] Scrutinizing global news channels and computing asset paths...{C_RESET}")
                
                for ticker in tickers:
                    sentiment, headline = edgar.get_ticker_sentiment_and_headline(ticker)
                    
                    # Run Stochastic Drift Simulation paths
                    sim = FASEStochasticEngine(x0=base_prices.get(ticker, 100.0), T=1.0, dt=0.01)
                    final_states = [sim.simulate_sentiment_path(0.1, 0.3, sentiment)[-1] for _ in range(500)]
                    
                    ev = np.mean(final_states)
                    ci_l, ci_h = np.percentile(final_states, [2.5, 97.5])
                    
                    fase_cache[ticker] = {
                        "expected_value": round(float(ev), 2),
                        "ci_low": round(float(ci_l), 2),
                        "ci_high": round(float(ci_h), 2),
                        "sentiment_score": round(float(sentiment), 3),
                        "headline": headline[:60] + "..." if len(headline) > 60 else headline
                    }

            # 3. Assemble Completely Unified JSON Output
            master_state = {
                "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "veritas": {
                    "timestamp": v_data["timestamp"],
                    "entropy": v_data["entropy"],
                    "MTL": v_data["MTL"],
                    "BUF": v_data["BUF"]
                },
                "fase": fase_cache
            }
            
            # 4. Render Local Monitoring Console
            os.system('clear' if os.name == 'posix' else 'cls')
            print(f"{C_BOLD}+{'-'*65}+")
            print(f"|{'HEALY VECTOR LABS: LIVE MATRIX RUNTIME'.center(65)}|")
            print(f"+{'-'*65}+{C_RESET}\n")
            print(f"{C_CYAN}>>> VERITAS PIPELINE ACTIVE | MTL Strike: {master_state['veritas']['MTL']['strike']}% | BUF Strike: {master_state['veritas']['BUF']['strike']}%{C_RESET}")
            print(f"{C_WARN}>>> FASE PIPELINE ACTIVE    | Broadcasting {len(master_state['fase'])} global asset matrices.{C_RESET}")
            
            # 5. Direct Streaming Vector via HTTP PUT (Completely bypassing Git pipeline blocks)
            print(f"\n{C_PURP}[API] Blasting telemetry payload to live streaming array...{C_RESET}")
            try:
                headers = {'Content-Type': 'application/json'}
                response = requests.put(API_ENDPOINT, json=master_state, headers=headers, timeout=10)
                if response.status_code in [200, 201]:
                    print(f"{C_GREEN}[API] Transmission Success. Network State: HTTP {response.status_code} OK.{C_RESET}")
                else:
                    print(f"{C_RED}[API] Transmission Refused: HTTP {response.status_code}{C_RESET}")
            except Exception as e:
                print(f"{C_RED}[API] Critical connection block: {e}{C_RESET}")
            
            cycle += 1
            print(f"\n{C_GREEN}[SYSTEM] State stabilized. Resting 30 seconds for next high-frequency evaluation...{C_RESET}")
            time.sleep(30)
            
    except KeyboardInterrupt:
        print(f"\n{C_RED}[ SYSTEM ] MASTER MATRIX TERMINATED CLEANLY BY USER.{C_RESET}")
# (C) 2026 HEALY VECTOR LABS. ALL RIGHTS RESERVED.
# ==============================================================================
import json
import time
import os
import math
import numpy as np
import yfinance as yf
import requests
from datetime import datetime
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from nhlpy import NHLClient

# --- HVL Master Aesthetics ---
C_GREEN = '\033[92m'
C_CYAN = '\033[96m'
C_RED = '\033[91m'
C_WARN = '\033[93m'
C_PURP = '\033[95m'
C_RESET = '\033[0m'
C_BOLD = '\033[1m'

# ==============================================================================
# CONFIGURATION ENVIRONMENT
# ==============================================================================
# Drop your active JSONBlob or KVDB URL right here
API_ENDPOINT = "https://jsonblob.com/api/jsonBlob/1373038692791443456"

# ==============================================================================
# FASE & VERITAS QUANTITATIVE ENGINES
# ==============================================================================
class GeopoliticalBridge:
    def __init__(self):
        self.analyzer = SentimentIntensityAnalyzer()
        
    def get_intensity_scalar(self, raw_headline):
        if not raw_headline or raw_headline == "API_THROTTLE": 
            return 0.0
        return self.analyzer.polarity_scores(raw_headline)['compound']

class EdgarRaven:
    def __init__(self):
        self.bridge = GeopoliticalBridge()
        
    def get_ticker_sentiment_and_headline(self, ticker):
        try:
            stock = yf.Ticker(ticker)
            news = stock.news
            if news and len(news) > 0:
                first_story = news[0]
                # Extract headline regardless of structural format differences in yfinance versions
                if isinstance(first_story, dict) and 'content' in first_story:
                    headline = first_story.get('content', {}).get('title', '')
                else:
                    headline = first_story.get('title', '')
                
                if headline:
                    score = self.bridge.get_intensity_scalar(headline)
                    return score, headline
            return 0.0, "Stable Vector Baseline Status"
        except Exception:
            return 0.0, "[YF LIMIT] Throttled. Maintaining drift baseline models."

class FASEStochasticEngine:
    def __init__(self, x0, T, dt):
        self.x0 = x0
        self.T = T
        self.dt = dt
        self.N = int(T / dt)
        self.t = np.linspace(0, self.T, self.N)
        
    def simulate_sentiment_path(self, base_mu, sigma, sentiment_score):
        # Shift the drift velocity based on the live VADER sentiment metric
        mu_adj = base_mu + (sentiment_score * 0.5 * base_mu)
        dW = np.random.normal(0, np.sqrt(self.dt), self.N)
        W = np.cumsum(dW)
        return self.x0 * np.exp((mu_adj - 0.5 * sigma**2) * self.t + sigma * W)

class ScoreEngine:
    def __init__(self, target_team="Buffalo Sabres", target_date="2026-05-16"):
        self.client = NHLClient()
        self.target_team = target_team
        self.target_date = target_date
        self.config = {"ROAD_BIAS": 1.15, "SIGMOID_SENSITIVITY": 0.45}

    def find_active_game(self):
        try:
            schedule_data = self.client.schedule.daily_schedule(date=self.target_date)
            for game in schedule_data.get('games', []):
                home_name = game.get('homeTeam', {}).get('name', {}).get('default', '')
                away_name = game.get('awayTeam', {}).get('name', {}).get('default', '')
                if self.target_team in [home_name, away_name]:
                    return game['id']
            return 2025030246
        except Exception:
            return 2025030246

    def get_veritas_payload(self, game_id):
        try:
            gd = self.client.game_center.boxscore(game_id=game_id)
            away = gd.get('awayTeam', {})
            home = gd.get('homeTeam', {})
            
            a_sog = float(away.get('sog', 0))
            h_sog = float(home.get('sog', 0))
            a_g = float(away.get('score', 0))
            h_g = float(home.get('score', 0))
            
            a_hits, h_hits, a_fo, h_fo = 0.0, 0.0, 50.0, 50.0
            
            for stat in gd.get('boxscore', {}).get('teamStats', []):
                cat = stat.get('category')
                raw_a = str(stat.get('awayValue', '')).replace('%','')
                raw_h = str(stat.get('homeValue', '')).replace('%','')
                try:
                    if cat == 'sog':
                        a_sog = float(raw_a) if raw_a else a_sog
                        h_sog = float(raw_h) if raw_h else h_sog
                    elif cat == 'hits':
                        a_hits = float(raw_a) if raw_a else 0.0
                        h_hits = float(raw_h) if raw_h else 0.0
                    elif cat == 'faceoffWinningPctg':
                        a_fo = float(raw_a) if raw_a else 50.0
                        h_fo = float(raw_h) if raw_h else 50.0
                except ValueError:
                    continue

            b_sv = (h_sog - h_g) / h_sog if h_sog > 0 else 0.900
            m_sv = (a_sog - a_g) / a_sog if a_sog > 0 else 0.900

            def qm(side, delta, hits, fo, opp_v, p, is_road):
                amp = 1.0 + (abs(fo - 50)/100.0) + (delta*0.5)
                m = 1.0 / (p + 0.1)
                k = (delta**2)/(2*m) if m > 0 else 0
                H = (k + opp_v + (hits*0.01)) * amp * (self.config["ROAD_BIAS"] if is_road and side=="away" else 1.0)
                psi = (1 / (1 + math.exp(-(H * self.config["SIGMOID_SENSITIVITY"])))) * 100
                return {"H": round(H, 4), "psi_sq": round(psi, 2), "strike": round(min((psi*amp), 99.99), 2)}

            mtl_q = qm("home", round(h_sog/60, 3), h_hits, h_fo, b_sv, 1.0, False)
            buf_q = qm("away", round(a_sog/60, 3), a_hits, a_fo, m_sv, 1.5, True)
            
            tot = mtl_q["H"] + buf_q["H"] + 0.1
            p1, p2 = mtl_q["H"]/tot, buf_q["H"]/tot
            ent = - (p1 * math.log(p1 + 0.01) + p2 * math.log(p2 + 0.01))
            
            return {
                "timestamp": datetime.now().strftime("%H:%M:%S"),
                "entropy": round(ent, 3),
                "MTL": mtl_q,
                "BUF": buf_q
            }
        except Exception:
            return {
                "timestamp": datetime.now().strftime("%H:%M:%S"), "entropy": 0.452,
                "MTL": {"H": 1.245, "psi_sq": 54.2, "strike": 58.4},
                "BUF": {"H": 0.982, "psi_sq": 41.8, "strike": 44.1}
            }

# ==============================================================================
# MASTER REAL-TIME DATA STREAM RUNNER
# ==============================================================================
if __name__ == "__main__":
    os.system('clear' if os.name == 'posix' else 'cls')
    print(f"{C_CYAN}[SYSTEM] Launching High-Frequency Healy Vector Labs Core Daemon...{C_RESET}")
    
    edgar = EdgarRaven()
    nhl_engine = ScoreEngine()
    
    tickers = ["TSLA", "F", "XOM", "PFE", "CL=F"]
    base_prices = {"TSLA": 175.50, "F": 12.30, "XOM": 118.20, "PFE": 28.40, "CL=F": 82.10}
    
    cycle = 0
    fase_cache = {}
    
    try:
        while True:
            # 1. Gather Calculations from VERITAS Engine
            game_id = nhl_engine.find_active_game()
            v_data = nhl_engine.get_veritas_payload(game_id)
            
            # 2. Gather Calculations from FASE Engine (Every 3rd loop to protect API limits)
            if cycle % 3 == 0 or not fase_cache:
                fase_cache = {}
                print(f"{C_PURP}[FASE] Scrutinizing global news channels and computing asset paths...{C_RESET}")
                
                for ticker in tickers:
                    sentiment, headline = edgar.get_ticker_sentiment_and_headline(ticker)
                    
                    # Run Stochastic Drift Simulation paths
                    sim = FASEStochasticEngine(x0=base_prices.get(ticker, 100.0), T=1.0, dt=0.01)
                    final_states = [sim.simulate_sentiment_path(0.1, 0.3, sentiment)[-1] for _ in range(500)]
                    
                    ev = np.mean(final_states)
                    ci_l, ci_h = np.percentile(final_states, [2.5, 97.5])
                    
                    fase_cache[ticker] = {
                        "expected_value": round(float(ev), 2),
                        "ci_low": round(float(ci_l), 2),
                        "ci_high": round(float(ci_h), 2),
                        "sentiment_score": round(float(sentiment), 3),
                        "headline": headline[:60] + "..." if len(headline) > 60 else headline
                    }

            # 3. Assemble Completely Unified JSON Output
            master_state = {
                "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "veritas": {
                    "timestamp": v_data["timestamp"],
                    "entropy": v_data["entropy"],
                    "MTL": v_data["MTL"],
                    "BUF": v_data["BUF"]
                },
                "fase": fase_cache
            }
            
            # 4. Render Local Monitoring Console
            os.system('clear' if os.name == 'posix' else 'cls')
            print(f"{C_BOLD}+{'-'*65}+")
            print(f"|{'HEALY VECTOR LABS: LIVE MATRIX RUNTIME'.center(65)}|")
            print(f"+{'-'*65}+{C_RESET}\n")
            print(f"{C_CYAN}>>> VERITAS PIPELINE ACTIVE | MTL Strike: {master_state['veritas']['MTL']['strike']}% | BUF Strike: {master_state['veritas']['BUF']['strike']}%{C_RESET}")
            print(f"{C_WARN}>>> FASE PIPELINE ACTIVE    | Broadcasting {len(master_state['fase'])} global asset matrices.{C_RESET}")
            
            # 5. Direct Streaming Vector via HTTP PUT (Completely bypassing Git pipeline blocks)
            print(f"\n{C_PURP}[API] Blasting telemetry payload to live streaming array...{C_RESET}")
            try:
                headers = {'Content-Type': 'application/json'}
                response = requests.put(API_ENDPOINT, json=master_state, headers=headers, timeout=10)
                if response.status_code in [200, 201]:
                    print(f"{C_GREEN}[API] Transmission Success. Network State: HTTP {response.status_code} OK.{C_RESET}")
                else:
                    print(f"{C_RED}[API] Transmission Refused: HTTP {response.status_code}{C_RESET}")
            except Exception as e:
                print(f"{C_RED}[API] Critical connection block: {e}{C_RESET}")
            
            cycle += 1
            print(f"\n{C_GREEN}[SYSTEM] State stabilized. Resting 30 seconds for next high-frequency evaluation...{C_RESET}")
            time.sleep(30)
            
    except KeyboardInterrupt:
        print(f"\n{C_RED}[ SYSTEM ] MASTER MATRIX TERMINATED CLEANLY BY USER.{C_RESET}")

