import os

# Target configuration
output_filename = "hvl_bundle.md"
include_extensions = ('.py', '.sh', '.json')
exclude_dirs = {'.git', '__pycache__', '.pytest_cache'}
exclude_files = {'bundle_repo.py', 'hvl_bundle.md'}

print(f"[*] Initializing codebase flattening for GAIS...")

with open(output_filename, 'w', encoding='utf-8') as outfile:
    # Walk through the directory tree
    for root, dirs, files in os.walk('.'):
        # Prune excluded directories in place
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for file in files:
            if file.endswith(include_extensions) and file not in exclude_files:
                relative_path = os.path.relpath(os.path.join(root, file), '.')
                
                # Write structured markdown dividers for LLM context tracking
                outfile.write(f"\n\n# ==========================================\n")
                outfile.write(f"# FILE: {relative_path}\n")
                outfile.write(f"# ==========================================\n\n")
                
                # Detect extension type for syntax highlighting blocks
                ext = file.split('.')[-1]
                lang = 'python' if ext == 'py' else ext
                
                outfile.write(f"```{lang}\n")
                try:
                    with open(os.path.join(root, file), 'r', encoding='utf-8', errors='ignore') as infile:
                        outfile.write(infile.read())
                except Exception as e:
                    outfile.write(f"# Error reading file contents: {str(e)}\n")
                outfile.write(f"\n```\n")
                
                print(f"[+] Packaged: {relative_path}")

print(f"\n[!] Success. Single-file context generated: {output_filename}")
