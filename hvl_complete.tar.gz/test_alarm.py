import socket
import json
import time

print("Sending FAKE BUY SIGNAL to the Router in 3 seconds...")
time.sleep(3)

fake_buy_signal = {
    "action": "BUY", 
    "strike": 77100, 
    "premium": 55
}

try:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect(('127.0.0.1', 65432))
        s.sendall(json.dumps(fake_buy_signal).encode('utf-8'))
        
        print("Signal sent! Check your Router window (and your phone lock screen).")
        print("Go type 'Y' in the Router window so this script can finish.")
        
        # Wait for you to type Y/N
        response = s.recv(1024).decode('utf-8')
        print(f"\nThe Router replied: {response}")
        print("Test Complete!")
        
except ConnectionRefusedError:
    print("FAILED: The Router isn't running! Go start btc_router.py first.")
