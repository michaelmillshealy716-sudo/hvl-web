import json
import time
import os
import math
from datetime import datetime, timedelta
from nhlpy import NHLClient

# --- HVL Master Aesthetics ---
C_GREEN = '\033[92m'
C_BLUE = '\033[94m'
C_CYAN = '\033[96m'
C_RED = '\033[91m'
C_WARN = '\033[93m'
C_PURP = '\033[95m'
C_RESET = '\033[0m'
C_BOLD = '\033[1m'

class ScoreEngine:
    def __init__(self, target_team="Buffalo Sabres", target_date="2026-05-16"):
        self.client = NHLClient()
        self.target_team = target_team
        self.target_date = target_date
        self.history_file = "series_history.json"
        
        self.team_data = {
            "away": {"last_delta": 0.0, "last_time": datetime.now(), "name": "MTL"},
            "home": {"last_delta": 0.0, "last_time": datetime.now(), "name": "BUF"}
        }
        
        # Barriers and Road Multipliers
        self.config = {
            "ROAD_BIAS": 1.15, # 15% boost for BUF playoff road dominance
            "SIGMOID_SENSITIVITY": 0.45
        }

    def find_active_game(self):
        try:
            schedule = self.client.schedule.daily_schedule(date=self.target_date)
            for game in schedule.get('games', []):
                home_name = game.get('homeTeam', {}).get('name', {}).get('default', '')
                away_name = game.get('awayTeam', {}).get('name', {}).get('default', '')
                if self.target_team in [home_name, away_name]:
                    return game['id']
            return 2025030246 # Fallback ID for testing
        except: 
            return 2025030246

    def calculate_entropy(self, mtl_h, buf_h):
        """Calculates system entropy (chaos). High when energies are equal."""
        total = mtl_h + buf_h + 0.1
        p1, p2 = mtl_h / total, buf_h / total
        entropy = - (p1 * math.log(p1 + 0.01) + p2 * math.log(p2 + 0.01))
        return round(entropy, 3)

    def calculate_quantum_metrics(self, side, delta, hits, fo_pct, opponent_v, pressure, is_road):
        """H = [ (p^2 / 2m) + V ] * I * A * Road_Bias"""
        # 1. Possession Wave (A)
        possession_amp = 1.0 + (abs(fo_pct - 50) / 100.0) + (delta * 0.5)
        
        # 2. Mass/Desperation (m)
        mass = 1.0 / (pressure + 0.1)
        kinetic = (delta**2) / (2 * mass) if mass > 0 else 0
        
        # 3. Road Bias
        road_mult = self.config["ROAD_BIAS"] if (is_road and side == "away") else 1.0
        
        # 4. Hamiltonian (Total Energy)
        hamiltonian = (kinetic + opponent_v + (hits * 0.01)) * possession_amp * road_mult
        
        # 5. Normalized Probability (Psi^2)
        psi_sq = (1 / (1 + math.exp(-(hamiltonian * self.config["SIGMOID_SENSITIVITY"])))) * 100
        strike_chance = min((psi_sq * possession_amp), 99.99)
        
        return {
            "H": round(hamiltonian, 4),
            "psi_sq": round(psi_sq, 2),
            "strike": round(strike_chance, 2),
            "amp": round(possession_amp, 3)
        }

    def get_veritas_payload(self, game_id):
        try:
            game_data = self.client.game_center.boxscore(game_id=game_id)
            if not isinstance(game_data, dict):
                raise ValueError("Payload returned unexpected raw data type.")

            away_meta = game_data.get('awayTeam', {})
            home_meta = game_data.get('homeTeam', {})
            
            # Establish baseline values from top level fields
            away_sog = float(away_meta.get('sog', 0))
            home_sog = float(home_meta.get('sog', 0))
            away_goals = float(away_meta.get('score', 0))
            home_goals = float(home_meta.get('score', 0))
            
            away_hits, home_hits = 0.0, 0.0
            away_fo, home_fo = 50.0, 50.0
            
            # Safely crawl and parse modern live telemetry array matrices
            boxscore_layer = game_data.get('boxscore', {})
            team_stats_list = boxscore_layer.get('teamStats', [])
            
            for stat in team_stats_list:
                category = stat.get('category')
                raw_away = str(stat.get('awayValue', '')).replace('%', '').strip()
                raw_home = str(stat.get('homeValue', '')).replace('%', '').strip()
                
                try:
                    if category == 'sog':
                        away_sog = float(raw_away) if raw_away else away_sog
                        home_sog = float(raw_home) if raw_home else home_sog
                    elif category == 'hits':
                        away_hits = float(raw_away) if raw_away else 0.0
                        home_hits = float(raw_home) if raw_home else 0.0
                    elif category == 'faceoffWinningPctg':
                        away_fo = float(raw_away) if raw_away else 50.0
                        home_fo = float(raw_home) if raw_home else 50.0
                except ValueError:
                    continue

            # Calculate dynamic live SV% for the potential barriers (V)
            # Default to league average (0.900) if no shots have been fired yet
            buf_goalie_sv = (home_sog - home_goals) / home_sog if home_sog > 0 else 0.900
            mtl_goalie_sv = (away_sog - away_goals) / away_sog if away_sog > 0 else 0.900

            # MTL is Home for Game 6, BUF is Away.
            mtl_q = self.calculate_quantum_metrics(
                "home", round(home_sog/60, 3), home_hits, home_fo, buf_goalie_sv, 1.0, False
            )
            
            buf_q = self.calculate_quantum_metrics(
                "away", round(away_sog/60, 3), away_hits, away_fo, mtl_goalie_sv, 1.50, True
            )
            
            entropy = self.calculate_entropy(mtl_q["H"], buf_q["H"])
            
            payload = {
                "timestamp": datetime.now().strftime("%H:%M:%S"),
                "MTL": mtl_q,
                "BUF": buf_q,
                "entropy": entropy,
                "metadata": {
                    "Hamiltonian": "Total system energy (Kinetic + Potential).",
                    "Psi_Squared": "Probability density of a state-change event (Goal).",
                    "Entropy": "Measure of system chaos vs stability.",
                    "Road_Warrior_Bias": "Multiplier for Buffalo road dominance (4-1 in playoffs)."
                }
            }
            
            self.save_persistence(payload)
            return payload
            
        except Exception as e:
            print(f"{C_RED}[ ERR ] Telemetry Exception: {e}{C_RESET}")
            return None

    def save_persistence(self, data):
        history = []
        if os.path.exists(self.history_file):
            with open(self.history_file, 'r') as f:
                try: history = json.load(f)
                except: history = []
        
        history.append(data)
        with open(self.history_file, 'w') as f:
            json.dump(history[-50:], f, indent=4) 

def render_cli_dashboard(data):
    """Cleanly formats and renders the quantum core telemetry to stdout."""
    os.system('clear' if os.name == 'posix' else 'cls')
    
    # Header
    print(f"{C_BOLD}+{'-'*58}+")
    print(f"|{'HEALY VECTOR LABS: QUANTUM CORE V7.0'.center(58)}|")
    print(f"|{'EXPLICITORY METADATA ENABLED'.center(58)}|")
    print(f"+{'-'*58}+{C_RESET}\n")

    # Core Metrics
    print(f"System Entropy: {C_CYAN}{data['entropy']}{C_RESET} S\n")
    print(f"{'METRIC':<15} | {'MTL (HOME)':<15} | {'BUF (AWAY)':<15}")
    print("-" * 52)
    print(f"{'Possession A':<15} | {data['MTL']['amp']:<15} | {data['BUF']['amp']:<15}")
    print(f"{'Hamiltonian':<15} | {C_GREEN}{data['MTL']['H']:<15}{C_RESET} | {C_GREEN}{data['BUF']['H']:<15}{C_RESET}")
    print(f"{'Collapse %':<15} | {data['MTL']['psi_sq']:<15} | {data['BUF']['psi_sq']:<15}")

    # Strike Readout
    m_strike = data['MTL']['strike']
    b_strike = data['BUF']['strike']
    m_color = C_GREEN if m_strike > 65 else C_WARN
    b_color = C_GREEN if b_strike > 65 else C_WARN

    print(f"\n{C_BOLD}GOAL STRIKE    | {m_color}{m_strike:>14}%{C_RESET} | {b_color}{b_strike:>14}%{C_RESET}")
    print(f"\n{C_PURP}Explicitory Metadata Loaded. Archive Sync: OK.{C_RESET}")

if __name__ == "__main__":
    engine = ScoreEngine()
    
    try:
        while True:
            game_id = engine.find_active_game()
            data = engine.get_veritas_payload(game_id)
            
            if data:
                # 1. Render the CLI Dashboard to terminal
                render_cli_dashboard(data)
                
                # 2. Live Web Sync Pipeline (HealyVectorLabs.com Frontend Route)
                try:
                    web_payload = {
                        "timestamp": data["timestamp"],
                        "entropy": data["entropy"],
                        "teams": {
                            "MTL": {
                                "hamiltonian": data["MTL"]["H"],
                                "psi_squared": data["MTL"]["psi_sq"],
                                "strike_chance": data["MTL"]["strike"]
                            },
                            "BUF": {
                                "hamiltonian": data["BUF"]["H"],
                                "psi_squared": data["BUF"]["psi_sq"],
                                "strike_chance": data["BUF"]["strike"]
                            }
                        }
                    }
                    
                    with open("live_score.json", "w") as wf:
                        json.dump(web_payload, wf, indent=4)
                    
                    # Native Git Push utilizing HEAD:main to bypass local branch name mismatches
                    os.system("git add live_score.json && git commit -m 'TELEMETRY SYNC: VERITAS' --quiet && git push origin HEAD:main --quiet")
                        
                except Exception as sync_err:
                    print(f"\033[91m[TELEMETRY ERROR] Dynamic sync drop: {sync_err}\033[0m")
                
            time.sleep(30)
            
    except KeyboardInterrupt:
        print(f"\n{C_RED}[ SYSTEM ] ARCHIVE LOCKED AND COLD STORED.{C_RESET}")

