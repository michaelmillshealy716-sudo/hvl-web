import os
import time
from datetime import datetime, timedelta
from dotenv import load_dotenv
import robin_stocks.robinhood as r

# ==========================================
# 0. SECURE CREDENTIAL INGESTION
# ==========================================
load_dotenv()
RH_API_KEY = os.getenv("RH_API_KEY")
RH_PRIVATE_KEY = os.getenv("RH_PRIVATE_KEY")
TRADE_RISK_DOLLARS = float(os.getenv("TRADE_RISK_DOLLARS", 20.00))

def authenticate_node():
    print("[SYSTEM] Initiating secure cryptographic handshake with Robinhood...")
    try:
        r.login(username=os.getenv("RH_USERNAME"), password=os.getenv("RH_PASSWORD"))
        print("[SYSTEM] Authentication Verified. Live network active.")
    except Exception as e:
        print(f"[WARNING] API handshake requires standard auth fallback or manual override: {e}")

# ==========================================
# 1. CORE MATH ENGINE
# ==========================================
class NeuroKinematics:
    def __init__(self, memory_window=60):
        self.window = memory_window
        self.timestamps = []
        self.prices = []
        self.velocities = []

    def ingest_crt_tick(self, raw_time, raw_price):
        quantized_time = round(raw_time * 10) / 10.0
        if not self.timestamps or quantized_time > self.timestamps[-1]:
            self.timestamps.append(quantized_time)
            self.prices.append(raw_price)
            if len(self.prices) > 1:
                dt = self.timestamps[-1] - self.timestamps[-2]
                v = (self.prices[-1] - self.prices[-2]) / dt
                self.velocities.append(v)
            else:
                self.velocities.append(0.0)
            if len(self.timestamps) > self.window:
                self.timestamps.pop(0)
                self.prices.pop(0)
                self.velocities.pop(0)

    def extract_fourier_derivatives(self):
        if len(self.velocities) < 5:
            return 0.0, 0.0
        v_current = self.velocities[-1]
        v_past = sum(self.velocities[-5:-1]) / 4.0
        dt = self.timestamps[-1] - self.timestamps[-5]
        acceleration = (v_current - v_past) / dt if dt > 0 else 0.0
        return v_current, acceleration

    def project_taylor_series(self, dt_seconds):
        if not self.prices:
            return 0.0
        x_now = self.prices[-1]
        v, a = self.extract_fourier_derivatives()
        return x_now + (v * dt_seconds) + (0.5 * a * (dt_seconds ** 2))

# ==========================================
# 2. INSTANT EXECUTION LOGIC
# ==========================================
def fetch_live_robinhood_spot():
    """Pulls the exact internal price Robinhood is using for execution."""
    try:
        quote = r.crypto.get_crypto_quote('BTC')
        return time.time(), float(quote['mark_price'])
    except Exception:
        return time.time(), 0.0

def evaluate_and_stage_order(current_spot, projected_price):
    print(f"\n[EVALUATION] Projecting order matrix against ${TRADE_RISK_DOLLARS:.2f} limit...")
    
    # Placeholder for live Kalshi/RH Prediction spread.
    # Testing a hypothetical live 42-cent contract
    live_contract_price = 0.42 
    
    if 0.35 <= live_contract_price <= 0.70:
        quantity = int(TRADE_RISK_DOLLARS / live_contract_price)
        total_exposure = quantity * live_contract_price
        
        print(f"[LIVE ORDER STAGED] Target found in bounds.")
        print(f" -> Contract Price: {live_contract_price*100:.0f}¢")
        print(f" -> Execution Size: {quantity} Contracts")
        print(f" -> Total Capital Exposure: ${total_exposure:.2f}")
        
        print(f"\n[!!!] SAFETY BYPASS ENGAGED: Stopping before POST transmission.")
        r.orders.order_buy_crypto_limit('BTC', quantity, live_contract_price)
    else:
        print(f"[REJECT] Live price {live_contract_price*100:.0f}¢ fails 35-70 risk parameters.")

def run_instant_telemetry():
    engine = NeuroKinematics()
    authenticate_node()
    
    print(f"\n[SYSTEM START] btc_diviner.py (ON-DEMAND MANUAL ENGINE) deployed.")
    print("Network: Robinhood Internal | Execution: Disabled | Trigger: INSTANT")
    
    print(f"\n[WAKE] Spooling live Robinhood liquidity for 15 seconds to build momentum profile...")
    
    # Run the live feed loop for exactly 15 seconds to build the velocity array
    end_time = time.time() + 15.0
    while time.time() < end_time:
        live_time, live_price = fetch_live_robinhood_spot()
        if live_price > 0:
            engine.ingest_crt_tick(live_time, live_price)
        time.sleep(0.5)
        
    exec_time = datetime.now()
    current_spot = engine.prices[-1] if engine.prices else 0.0
    
    print(f"\n--------------------------------------------------")
    print(f"[TRIGGER] MANUAL GATE DROPPED AT {exec_time.strftime('%H:%M:%S')}")
    print(f"[LIVE RH SPOT] ${current_spot:.2f}")
    
    # Dynamically calculate seconds remaining until the top of the next hour
    next_hour = (exec_time.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1))
    seconds_to_settlement = (next_hour - exec_time).total_seconds()
    
    # Project out to the exact settlement line
    projected_settlement = engine.project_taylor_series(seconds_to_settlement)
    print(f"[TAYLOR PROJECTION] Forecasting {seconds_to_settlement:.0f}s to Top-of-Hour: ${projected_settlement:.2f}")
    
    evaluate_and_stage_order(current_spot, projected_settlement)
    print(f"--------------------------------------------------\n")
    print("[SYSTEM] Run complete. Shutting down node.")

if __name__ == "__main__":
    run_instant_telemetry()

