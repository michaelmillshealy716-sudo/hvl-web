import os
import time
import json
import numpy as np
from datetime import datetime, timedelta
from dotenv import load_dotenv
import robin_stocks.robinhood as r

# ---------------------------------------------------------
# 0. SECURE CREDENTIAL INGESTION & UI FORMATTING
# ---------------------------------------------------------
load_dotenv()
GREEN = '\033[92m'
RED = '\033[91m'
RESET = '\033[0m'

def authenticate_node():
    print("[*SYSTEM] Initiating secure cryptographic handshake with Robinhood...")
    try:
        # Using robin_stocks standard auth (ensure RH_USERNAME/PASSWORD are in .env)
        # Note: For the official API key (Crypto_walk), a different requests-based payload is needed,
        # but robin_stocks is currently the most robust wrapper for Python.
        r.login(username=os.getenv("RH_USERNAME"), password=os.getenv("RH_PASSWORD"))
        print(f"{GREEN}[*SYSTEM] Authentication Verified. Live network active.{RESET}")
    except Exception as e:
        print(f"{RED}[WARNING] API handshake issue: {e}{RESET}")
        exit(1)

# ---------------------------------------------------------
# 1. CORE MATH ENGINE (KINEMATICS + GALOIS LEARNING)
# ---------------------------------------------------------
class NeuroKinematics:
    def __init__(self, memory_window=60):
        self.window = memory_window
        self.timestamps = []
        self.prices = []
        self.volumes = [] # ADDED: Volume tracking
        self.velocities = []
        self.accelerations = [] 

    def ingest_crt_tick(self, raw_time, raw_price, raw_volume):
        quantized_time = round(raw_time * 10) / 10.0
        if not self.timestamps or quantized_time > self.timestamps[-1]:
            self.timestamps.append(quantized_time)
            self.prices.append(raw_price)
            self.volumes.append(raw_volume) # Store volume
            
            if len(self.prices) > 1:
                dt = self.timestamps[-1] - self.timestamps[-2]
                v = (self.prices[-1] - self.prices[-2]) / dt if dt != 0 else 0
                self.velocities.append(v)
            else:
                self.velocities.append(0.0)

            # Enforce memory bounds
            if len(self.prices) > self.window:
                self.timestamps.pop(0)
                self.prices.pop(0)
                self.volumes.pop(0)
                self.velocities.pop(0)

    def extract_fourier_derivatives(self):
        if len(self.velocities) < 5:
            return 0.0, 0.0
        v_current = self.velocities[-1]
        v_past = sum(self.velocities[-5:-1]) / 4.0
        dt = self.timestamps[-1] - self.timestamps[-5]
        acceleration = (v_current - v_past) / dt if dt != 0 else 0.0
        
        self.accelerations.append(acceleration)
        if len(self.accelerations) > self.window:
            self.accelerations.pop(0)
            
        return v_current, acceleration

    def project_taylor_series(self, dt_seconds):
        if len(self.prices) < 2:
            return self.prices[-1] if self.prices else 0.0
            
        x_now = self.prices[-1]
        v, a = self.extract_fourier_derivatives()
        
        # PATCH 1: LINEAR DAMPENING (Capping the explosive dt^2 variable)
        # This stops the engine from projecting $600 spikes on 60-second noise.
        time_decay_factor = max(0.1, 1.0 - (dt_seconds / 3600.0)) 
        projected_target = x_now + (v * dt_seconds * time_decay_factor)
        
        return projected_target

class AdaptiveGaloisEngine:
    def __init__(self):
        self.attributes = ['HIGH_V_UP', 'POSITIVE_ACCEL', 'VOLUME_CONFIRMED']

    def check_lattice_lock(self, kinematics, current_price, projected_price):
        if len(kinematics.velocities) < 10:
            return False, "LEARNING_PHASE"
            
        # SELF-LEARNING: Calculate dynamic thresholds
        rolling_v_std = np.std(kinematics.velocities[-10:])
        rolling_vol_avg = np.mean(kinematics.volumes[-10:])
        
        current_v = kinematics.velocities[-1]
        current_a = kinematics.accelerations[-1] if kinematics.accelerations else 0.0
        current_vol = kinematics.volumes[-1]

        # PATCH 2: INCREASED SIGMA TO 2.5 (Stops trading random noise)
        is_high_v_up = 1 if current_v > (rolling_v_std * 2.00) else 0 
        is_pos_accel = 1 if current_a > 0 else 0
        
        # PATCH 3: VOLUME CONFIRMATION (Prevents fake-out traps)
        is_vol_confirmed = 1 if current_vol > (rolling_vol_avg * 1.1) else 0

        # Galois Derivation
        if is_high_v_up and is_pos_accel and is_vol_confirmed:
            return True, f"{GREEN}[EXECUTE BUY - GALOIS LOCKED]{RESET}"
        else:
            return False, "[OBSERVING]"

# ---------------------------------------------------------
# 2. THE ORDER ROUTER (HOW YOU MAKE TRADES)
# ---------------------------------------------------------
def execute_spot_trade(amount_in_dollars):
    """
    This is the function that actually moves your money.
    It tells Robinhood to execute a market buy for $X of Bitcoin.
    """
    try:
        print(f"\n{GREEN}[>>> ROUTING ORDER] Purchasing ${amount_in_dollars} of BTC...{RESET}")
        # UNCOMMENT THE LINE BELOW TO ACTUALLY BUY REAL BITCOIN WITH REAL MONEY
        receipt = r.orders.order_buy_crypto_by_price('BTC', amountInDollars=amount_in_dollars)
        # print(f"[{datetime.now()}] SUCCESS: Fill details saved to logs.")
        print(f"[TEST MODE] API Call simulated. Target: Buy ${amount_in_dollars} BTC.")
    except Exception as e:
        print(f"{RED}[ROUTING ERROR] Execution failed: {e}{RESET}")

# ---------------------------------------------------------
# 3. DAEMON LOOP (THE PRODUCER)
# ---------------------------------------------------------
def fetch_live_robinhood_spot():
    try:
        quote = r.crypto.get_crypto_quote('BTC')
        return time.time(), float(quote['mark_price']), float(quote['volume'])
    except Exception:
        return time.time(), 0.0, 0.0

def run_signal_daemon():
    authenticate_node()
    engine = NeuroKinematics(memory_window=60)
    galois = AdaptiveGaloisEngine()
    
    print("\n[*ALPHA NODE] Daemon initialized. Entering continuous heartbeat loop.")
    print(f"{'TIME':<12} | {'SPOT PRICE':<12} | {'FORECAST':<12} | {'GALOIS STATE'}")
    print("-" * 65)

    last_trade_time = datetime.now() - timedelta(minutes=15) # Cooldown timer

    while True:
        # 1. Ingest Data
        live_time, live_price, live_volume = fetch_live_robinhood_spot()
        if live_price > 0:
            engine.ingest_crt_tick(live_time, live_price, live_volume)

        # 2. Project Math
        exec_time = datetime.now()
        next_hour = (exec_time.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1))
        seconds_to_settlement = (next_hour - exec_time).total_seconds()
        
        projected_settlement = engine.project_taylor_series(seconds_to_settlement)

        # 3. Evaluate Signal
        lock_achieved, galois_status = galois.check_lattice_lock(engine, live_price, projected_settlement)

        # 4. Print Output
        time_str = exec_time.strftime('%H:%M:%S')
        print(f"{time_str:<12} | ${live_price:<11.2f} | ${projected_settlement:<11.2f} | {galois_status}")

        # 5. EXECUTION LOGIC (MONEY ROUTING)
        time_since_last_trade = (datetime.now() - last_trade_time).total_seconds()
        
        # If signal fires AND we haven't traded in the last 5 minutes (Cooldown)
        if lock_achieved and time_since_last_trade > 300:
            # We execute a trade for $10 of Bitcoin
            execute_spot_trade(amount_in_dollars=10.00) 
            last_trade_time = datetime.now()

        # 6. Sleep
        time.sleep(60.0)

if __name__ == "__main__":
    run_signal_daemon()
