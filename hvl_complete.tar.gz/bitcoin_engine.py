import os, time, json, math, socket
import numpy as np
from datetime import datetime, timedelta
from dotenv import load_dotenv
import robin_stocks.robinhood as r

load_dotenv()

def authenticate_node():
    r.login(username=os.getenv("RH_USERNAME"), password=os.getenv("RH_PASSWORD"))

class NeuroKinematics:
    def __init__(self):
        self.timestamps, self.prices, self.volumes = [], [], []
        self.velocities, self.accelerations = [], []
        self.buffer_limit = 60

    def ingest_crt_tick(self, t, price, vol):
        self.timestamps.append(t); self.prices.append(price); self.volumes.append(vol)
        if len(self.prices) > 1:
            dt = self.timestamps[-1] - self.timestamps[-2]
            self.velocities.append((self.prices[-1] - self.prices[-2]) / dt if dt != 0 else 0)
        else: 
            self.velocities.append(0.0)

        if len(self.velocities) > 4:
            v_past = sum(self.velocities[-5:-1]) / 4.0
            dt = self.timestamps[-1] - self.timestamps[-5]
            self.accelerations.append((self.velocities[-1] - v_past) / dt if dt != 0 else 0)
        else: 
            self.accelerations.append(0.0)

        if len(self.prices) > self.buffer_limit:
            self.timestamps.pop(0); self.prices.pop(0); self.volumes.pop(0)
            self.velocities.pop(0); self.accelerations.pop(0)

    def get_vwma(self, period=15):
        if len(self.prices) < period: return self.prices[-1] if self.prices else 0.0
        prices_arr = np.array(self.prices[-period:])
        vols_arr = np.array(self.volumes[-period:])
        if np.sum(vols_arr) == 0: return np.mean(prices_arr) 
        return np.sum(prices_arr * vols_arr) / np.sum(vols_arr)

    def project_taylor_series(self, dt_seconds):
        if len(self.prices) < 2: return 0.0
        time_decay = max(0.1, 1.0 - (dt_seconds / 3600.0))
        return self.prices[-1] + (self.velocities[-1] * dt_seconds * time_decay)

class DerivativeManager:
    def __init__(self):
        self.active_position = False
        self.entry_strike = 0.0
        self.entry_spot_price = 0.0  # NEW: Locks in true entry physics
        self.contract_type = ""
        self.max_profit_delta = 0.0

    def check_buy_lock(self, k, spot, projected, time_left):
        if len(k.velocities) < 20 or self.active_position: 
            return False, 0.0, "", "[OBSERVING]"
        
        v_std = np.std(k.velocities[-10:])
        vol_avg = np.mean(k.volumes[-10:])
        vwma = k.get_vwma(15)
        
        gamma_active = time_left < 1200
        vol_req = 1.1 if gamma_active else 1.2 
        
        # MICRO-MOMENTUM TRIPWIRES (Apex Entry Logic)
        price_delta_3 = spot - k.prices[-3] 
        micro_spike_up = price_delta_3 >= 15.0
        micro_spike_down = price_delta_3 <= -15.0

        price_delta_2 = spot - k.prices[-2]
        two_green_ticks = k.velocities[-1] > 0 and k.velocities[-2] > 0 and price_delta_2 >= 10.0
        two_red_ticks = k.velocities[-1] < 0 and k.velocities[-2] < 0 and price_delta_2 <= -10.0

        bull_vel = k.velocities[-1] > (v_std * 0.7)
        bull_vol = k.volumes[-1] > (vol_avg * vol_req)
        bear_vel = k.velocities[-1] < -(v_std * 0.7)
        bear_vol = k.volumes[-1] > (vol_avg * vol_req)

        # UPWARD MOMENTUM (YES)
        if (spot > vwma and bull_vol and bull_vel) or micro_spike_up or two_green_ticks:
            target_strike = math.ceil(spot / 100.0) * 100.0
            if (target_strike - spot) < 10.0: target_strike += 100.0
            
            if projected >= target_strike:
                self.max_profit_delta = 0.0
                msg_tag = "2-Tick Sequential Up" if two_green_ticks else "Bullish Micro-Spike"
                return True, target_strike, "YES", f"[RADAR] {msg_tag}. TGT: {target_strike}"
                
        # DOWNWARD MOMENTUM (NO)
        if (spot < vwma and bear_vol and bear_vel) or micro_spike_down or two_red_ticks:
            target_strike = math.floor(spot / 100.0) * 100.0
            if (spot - target_strike) < 10.0: target_strike -= 100.0
            
            if projected <= target_strike:
                self.max_profit_delta = 0.0
                msg_tag = "2-Tick Sequential Down" if two_red_ticks else "Bearish Micro-Spike"
                return True, target_strike, "NO", f"[RADAR] {msg_tag}. TGT: {target_strike}"
                
        status_msg = f"[OBSERVING] VWMA: {vwma:.2f} | 2-Tick: {price_delta_2:.2f}"
        if gamma_active: status_msg += " | GAMMA ACTIVE"
        return False, 0.0, "", status_msg

    def check_sell_lock(self, k, spot, time_left):
        if not self.active_position: 
            return False, "[NO POS]"
            
        # FIX: TRUE RELATIVE PnL DELTA VS EXPIRATION DISTANCE
        if self.contract_type == "YES":
            trade_delta = spot - self.entry_spot_price
            strike_distance = spot - self.entry_strike
            momentum_dead = (k.velocities[-1] < 0)
        else: 
            trade_delta = self.entry_spot_price - spot
            strike_distance = self.entry_strike - spot
            momentum_dead = (k.velocities[-1] > 0)
            
        # 1. THE TRAILING WATERMARK (Tied to Trade Delta, not Strike)
        if trade_delta > self.max_profit_delta:
            self.max_profit_delta = trade_delta
            
        pullback_from_peak = self.max_profit_delta - trade_delta
        
        price_delta_5 = spot - k.prices[-5]
        momentum_failing_macro = (self.contract_type == "YES" and price_delta_5 < 0) or (self.contract_type == "NO" and price_delta_5 > 0)
        
        # 2. SCALP PROFIT TAKE (Trailing Stop)
        # If it moves 30 points in your favor, trail it by 20 points.
        if self.max_profit_delta >= 30.0:
            if pullback_from_peak >= 20.0:
                return True, f"Trailing Stop Hit. Peak was +{self.max_profit_delta:.2f} Pts. Securing profit."
                
        # 3. EXPANDED RELATIVE STOP LOSS
        # You will only be stopped out if the asset literally drops 45 points from the EXACT moment you bought.
        if trade_delta < -45.0 and momentum_failing_macro:
            return True, f"Support collapsed. Trade dropped {trade_delta:.2f} Pts. CUT LOSSES."
            
        # 4. EXPIRATION DEATH
        # This evaluates the absolute strike distance to save you from expiring at $0.00
        if time_left < 120 and strike_distance < 15.0:
            return True, "Expiration imminent. Liquidation mandatory."
            
        return False, f"[{self.contract_type} TGT: {self.entry_strike}] PnL Delta: {trade_delta:.2f} | Peak: +{self.max_profit_delta:.2f}"

def send_signal(payload):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect(('127.0.0.1', 65432))
            s.sendall(json.dumps(payload).encode('utf-8'))
            return s.recv(1024).decode('utf-8') == "CONFIRMED"
    except: 
        return False

def run_daemon():
    authenticate_node()
    engine = NeuroKinematics()
    manager = DerivativeManager()
    print("\n[*SYSTEM] Relative PnL Tracking Engine Online...")
    
    last_cum_vol = 0.0
    
    while True:
        try:
            quote = r.crypto.get_crypto_quote('BTC')
            if not quote or 'mark_price' not in quote:
                time.sleep(1.0)
                continue
                
            spot = float(quote['mark_price'])
            cum_vol = float(quote['volume'])
            t = time.time()
            
            tick_vol = max(0.0, cum_vol - last_cum_vol) if last_cum_vol > 0 else 1.0
            last_cum_vol = cum_vol
            
            engine.ingest_crt_tick(t, spot, tick_vol)
            
            now = datetime.now()
            next_hour = (now.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1))
            seconds_left = (next_hour - now).total_seconds()
            
            projected = engine.project_taylor_series(seconds_left)
            buffer_count = len(engine.prices)
            
            if not manager.active_position:
                buy_now, strike, contract_type, msg = manager.check_buy_lock(engine, spot, projected, seconds_left)
                print(f"[{now.strftime('%H:%M:%S')}] | BTC: {spot:<9.2f} | {buffer_count}/60 | {msg}")
                
                if buy_now:
                    if send_signal({"action": "BUY", "contract": contract_type, "strike": strike, "range_min": 10, "range_max": 65}):
                        manager.active_position = True
                        manager.entry_strike = strike
                        manager.entry_spot_price = spot  # SECURING THE RELATIVE LAUNCH PAD
                        manager.contract_type = contract_type
                        time.sleep(10)
            else:
                sell_now, msg = manager.check_sell_lock(engine, spot, seconds_left)
                print(f"[{now.strftime('%H:%M:%S')}] | BTC: {spot:<9.2f} | {buffer_count}/60 | {msg}")
                
                if sell_now:
                    if send_signal({"action": "SELL", "contract": manager.contract_type, "strike": manager.entry_strike, "reason": msg}):
                        manager.active_position = False
                        manager.entry_strike = 0.0
                        manager.entry_spot_price = 0.0
                        manager.contract_type = ""
                        time.sleep(10)
            
            time.sleep(5)
        except Exception as e:
            time.sleep(5)

if __name__ == "__main__":
    run_daemon()
