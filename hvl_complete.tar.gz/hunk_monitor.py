# (c) 2026 HEALY VECTOR LABS. ALL RIGHTS RESERVED.
# FASE Engine V4.3 - Veritas Auditor Extension
# Hybrid API / Terminal Dashboard Architecture

import time
import datetime
import numpy as np
import yfinance as yf
import plotext as plt
import os
import warnings
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# Suppress API noise
warnings.filterwarnings("ignore")

app = FastAPI(title="FASE Engine API", version="4.3")

# Single-line middleware to prevent Termux paste-truncation
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

# --- HEALY VECTOR LABS: VERITAS V4.3 LOGIC ---

def get_euler_intrinsic(p_list):
    if len(p_list) < 10: return p_list[-1]
    f = np.fft.fft(p_list)
    f[len(f)//4:] = 0
    return np.real(np.fft.ifft(f)[-1])

def get_taylor_truth(p_hist):
    if len(p_hist) < 3: return 0.0
    v = p_hist[-1] - p_hist[-2]
    a = (p_hist[-1] - 2*p_hist[-2] + p_hist[-3])
    return abs((v * 0.5) + (a * 1.5)) * 10

def detect_markov_regime(t_score):
    if t_score > 4.10: return "BREAKOUT 🚀"
    elif t_score < 1.0: return "NOISE 🛑"
    else: return "STABLE 🏛️"

def get_volatility(p_hist):
    if len(p_hist) < 2: return 0.0
    returns = np.diff(np.log(p_hist))
    return np.std(returns) * np.sqrt(252) * 100

TICKERS = ['NVDA', 'TSLA', 'TSLL', 'XOM', 'USO', 'ERX' , 'PFE', 'WTI', 'BRK.B' ]

def compute_fase_state():
    data = yf.download(TICKERS, period="1d", interval="1m", progress=False)
    
    if data.empty:
        return {"error": "Failed to ingest market tape"}

    dates = data.index.strftime('%H:%M:%S').tolist()
    close_data = data['Close'] if 'Close' in data.columns else data['Adj Close']

    a_ticker, b_ticker = "USO", "XOM"
    a_p = close_data[a_ticker].dropna().values[-35:]
    b_p = close_data[b_ticker].dropna().values[-35:]
    
    a_z, b_z = [], []
    delta = 0.0

    if len(a_p) > 20:
        for i in range(15, len(a_p) + 1):
            min_a, min_b = a_p[:i], b_p[:i]
            mu_a, sig_a = get_euler_intrinsic(min_a), np.std(min_a)
            mu_b, sig_b = get_euler_intrinsic(min_b), np.std(min_b)
            
            a_z.append((min_a[-1] - mu_a) / sig_a if sig_a > 0 else 0)
            b_z.append((min_b[-1] - mu_b) / sig_b if sig_b > 0 else 0)
            
        delta = a_z[-1] - b_z[-1]

    hud_data = []
    for t in TICKERS:
        try:
            p_min = close_data[t].dropna().values[-30:]
            if len(p_min) < 5: continue
            
            curr_p = p_min[-1]
            mu = get_euler_intrinsic(p_min)
            sigma = np.std(p_min)
            z = (curr_p - mu) / sigma if sigma > 0 else 0
            
            truth = get_taylor_truth(p_min)
            regime = detect_markov_regime(truth)
            vol_pct = get_volatility(p_min)
            
            hud_data.append({
                "ticker": t,
                "price": round(curr_p, 2),
                "z_score": round(z, 2),
                "truth": round(truth, 4),
                "regime": regime,
                "vol_pct": round(vol_pct, 2)
            })
        except Exception:
            pass

    return {
        "timestamp": datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        "macro_gap": {
            "dates": dates[-len(a_z):] if len(a_z) > 0 else [],
            "a_ticker": a_ticker,
            "b_ticker": b_ticker,
            "a_z": [round(val, 4) for val in a_z],
            "b_z": [round(val, 4) for val in b_z],
            "arbitrage_delta": round(delta, 4)
        },
        "fleet_hud": hud_data
    }

@app.get("/api/v1/fase-data")
async def get_fase_data():
    return compute_fase_state()

def run_terminal_dashboard():
    print("Establishing FASE Macro Uplink... Calibrating Energy Correlates.")
    try:
        while True:
            state = compute_fase_state()
            if "error" in state:
                time.sleep(60)
                continue

            os.system('clear' if os.name == 'posix' else 'cls')
            print(f"--- HEALY VECTOR LABS | FASE V4.3 | {state['timestamp']} ---")
            
            mg = state["macro_gap"]
            
            plt.clf()
            plt.subplots(1, 2)
            
            plt.subplot(1, 1)
            plt.title(f"FASE Macro Gap: {mg['a_ticker']} (Blue) vs {mg['b_ticker']} (Red)")
            
            if mg["a_z"] and mg["b_z"] and mg["dates"]:
                max_len = min([len(mg["a_z"]), len(mg["b_z"]), len(mg["dates"])])
                
                a_z_plot = mg["a_z"][-max_len:]
                b_z_plot = mg["b_z"][-max_len:]
                dates_plot = mg["dates"][-max_len:]
                
                x_seq = list(range(max_len))
                
                plt.plot(x_seq, a_z_plot, label=f"{mg['a_ticker']} Z", color="blue")
                plt.plot(x_seq, b_z_plot, label=f"{mg['b_ticker']} Z", color="red")
                plt.xticks(x_seq, dates_plot)
                
            plt.hline(0, color="white")
            plt.plotsize(40, 15)

            plt.subplot(1, 2)
            plt.title("Momentum & Volatility Distribution")
            vol_tickers = [item['ticker'] for item in state['fleet_hud']]
            vol_vals = [item['vol_pct'] for item in state['fleet_hud']]
            
            if vol_tickers and vol_vals:
                plt.bar(vol_tickers, vol_vals, color="yellow")
                
            plt.plotsize(40, 15)
            plt.show()

            print(f"\n[FASE ARBITRAGE DELTA]: {mg['arbitrage_delta']} sigma")
            print("-" * 65)
            # Single-line F-strings to completely avoid Termux truncation
            print(f"{'TICKER':<6} {'PRICE':<9} {'Z-SCORE':<10} {'TRUTH':<10} {'VOL(%)':<10} {'REGIME':<15}")
            print("-" * 65)
            
            for item in state["fleet_hud"]:
                print(f"{item['ticker']:<6} ${item['price']:<8.2f} {item['z_score']:<10.2f} {item['truth']:<10.4f} {item['vol_pct']:<10.2f} {item['regime']:<15}")
            
            time.sleep(60)
            
    except KeyboardInterrupt:
        print("\n[!] Lead Architect terminated FASE Engine. Standing By.")

if __name__ == "__main__":
    run_terminal_dashboard()

