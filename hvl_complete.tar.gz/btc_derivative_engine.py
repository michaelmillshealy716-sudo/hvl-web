import os
import time
import json
import math
import numpy as np
from datetime import datetime, timedelta
from dotenv import load_dotenv
import robin_stocks.robinhood as r

# ---------------------------------------------------------
# 0. ENVIRONMENT & UI
# ---------------------------------------------------------
load_dotenv()
GREEN = '\033[92m'
RED = '\033[91m'
CYAN = '\033[96m'
YELLOW = '\033[93m'
RESET = '\033[0m'

def authenticate_node():
    print("[*SYSTEM] Initiating secure Spot feed handshake...")
    try:
        r.login(username=os.getenv("RH_USERNAME"), password=os.getenv("RH_PASSWORD"))
    except Exception as e:
        pass # Handle gracefully if using web-scraper concurrently

# ---------------------------------------------------------
# 1. CORE MATH ENGINE (KINEMATICS)
# ---------------------------------------------------------
class NeuroKinematics:
    def __init__(self, memory_window=60):
        self.window = memory_window
        self.timestamps, self.prices, self.volumes = [], [], []
        self.velocities, self.accelerations = [], []

    def ingest_crt_tick(self, raw_time, raw_price, raw_volume):
        self.timestamps.append(raw_time)
        self.prices.append(raw_price)
        self.volumes.append(raw_volume)
        
        if len(self.prices) > 1:
            dt = self.timestamps[-1] - self.timestamps[-2]
            v = (self.prices[-1] - self.prices[-2]) / dt if dt != 0 else 0
            self.velocities.append(v)
        else:
            self.velocities.append(0.0)

        if len(self.velocities) > 4:
            v_past = sum(self.velocities[-5:-1]) / 4.0
            dt = self.timestamps[-1] - self.timestamps[-5]
            a = (self.velocities[-1] - v_past) / dt if dt != 0 else 0.0
            self.accelerations.append(a)
        else:
            self.accelerations.append(0.0)

        # Enforce limits
        if len(self.prices) > self.window:
            self.timestamps.pop(0); self.prices.pop(0); self.volumes.pop(0)
            self.velocities.pop(0); self.accelerations.pop(0)

    def project_taylor_series(self, dt_seconds):
        if len(self.prices) < 2: return 0.0
        x_now = self.prices[-1]
        v = self.velocities[-1]
        time_decay = max(0.1, 1.0 - (dt_seconds / 3600.0)) # Linear dampening
        return x_now + (v * dt_seconds * time_decay)

# ---------------------------------------------------------
# 2. EVENT CONTRACT RISK MANAGER (GALOIS LOGIC)
# ---------------------------------------------------------
class DerivativeManager:
    def __init__(self):
        self.active_position = False
        self.entry_strike = 0.0
        self.entry_price = 0.0

    def calculate_target_strike(self, spot_price):
        """Finds the nearest Robinhood $100 interval strike above spot"""
        return math.ceil(spot_price / 100.0) * 100.0

    def check_buy_lock(self, kinematics, spot, projected):
        if len(kinematics.velocities) < 10 or self.active_position:
            return False, 0.0, "[WAITING]"

        v_std = np.std(kinematics.velocities[-10:])
        vol_avg = np.mean(kinematics.volumes[-10:])
        v_current, a_current, vol_current = kinematics.velocities[-1], kinematics.accelerations[-1], kinematics.volumes[-1]

        # 1. Kinematic Breakout Check (2.5 Sigma + Volume)
        if v_current > (v_std * 2.5) and a_current > 0 and vol_current > (vol_avg * 1.1):
            
            target_strike = self.calculate_target_strike(spot)
            
            # 2. Projection Check (Does the math actually think we cross the strike?)
            if projected > target_strike:
                return True, target_strike, f"{GREEN}[BUY LOCK] TARGET: ${target_strike} | MAX PREMIUM: 55¢{RESET}"
                
        return False, 0.0, "[OBSERVING]"

    def check_sell_lock(self, kinematics, spot, time_left_seconds):
        if not self.active_position: return False, "[NO POS]"

        v_current = kinematics.velocities[-1]
        a_current = kinematics.accelerations[-1]

        # Sell Condition A: Parabolic Take Profit (Spot blew past strike, momentum stalling)
        if spot > (self.entry_strike + 15) and a_current < 0:
            return True, f"{CYAN}[SELL TARGET] ITM TAKE PROFIT -> SPOT: ${spot:.2f}{RESET}"

        # Sell Condition B: Kinematic Reversal (Stop Loss - Cut before $0.00)
        if v_current < 0 and a_current < 0 and spot < self.entry_strike:
            return True, f"{YELLOW}[SELL TARGET] MOMENTUM REVERSAL BAILOUT -> CUT LOSS{RESET}"

        # Sell Condition C: Time Decay Wipeout (Less than 5 mins, not over strike)
        if time_left_seconds < 300 and spot < self.entry_strike:
            return True, f"{RED}[SELL TARGET] IMMINENT THETA DECAY -> LIQUIDATE NOW{RESET}"

        return False, f"[HOLDING ${self.entry_strike}]"

# ---------------------------------------------------------
# 3. LIVE DAEMON
# ---------------------------------------------------------
def fetch_mock_or_live_spot():
    # Replace with your actual live websocket or r.crypto fetch
    try:
        quote = r.crypto.get_crypto_quote('BTC')
        return time.time(), float(quote['mark_price']), float(quote['volume'])
    except:
        return time.time(), 0.0, 0.0

def run_derivative_daemon():
    authenticate_node()
    engine = NeuroKinematics(memory_window=60)
    derivative_ai = DerivativeManager()
    
    print("\n[*ALPHA NODE] Event Contract Derivative Engine Initialized.")
    print(f"{'TIME':<10} | {'SPOT':<10} | {'TGT STRIKE':<10} | {'ACTION/STATE'}")
    print("-" * 65)

    while True:
        # Ingest
        t, spot, vol = fetch_mock_or_live_spot()
        if spot > 0: engine.ingest_crt_tick(t, spot, vol)

        # Time Math
        now = datetime.now()
        next_hour = (now.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1))
        seconds_left = (next_hour - now).total_seconds()
        
        projected = engine.project_taylor_series(seconds_left)

        # State Machine Evaluation
        time_str = now.strftime('%H:%M:%S')
        
        if not derivative_ai.active_position:
            # LOOKING FOR BUY
            buy_triggered, strike, msg = derivative_ai.check_buy_lock(engine, spot, projected)
            print(f"{time_str:<10} | ${spot:<9.2f} | ${derivative_ai.calculate_target_strike(spot):<9.2f} | {msg}")
            
            if buy_triggered:
                # YOU WOULD HOOK YOUR ORDER ROUTER HERE
                derivative_ai.active_position = True
                derivative_ai.entry_strike = strike
                # Wait 60 seconds after buy to prevent instant sell loops
                time.sleep(60.0) 
                continue
                
        else:
            # LOOKING FOR SELL
            sell_triggered, msg = derivative_ai.check_sell_lock(engine, spot, seconds_left)
            print(f"{time_str:<10} | ${spot:<9.2f} | ${derivative_ai.entry_strike:<9.2f} | {msg}")
            
            if sell_triggered:
                # YOU WOULD HOOK YOUR ORDER ROUTER HERE
                derivative_ai.active_position = False
                derivative_ai.entry_strike = 0.0
                time.sleep(60.0)
                continue

        time.sleep(5.0) # Faster tick rate for derivative precision (5 secs instead of 60)

if __name__ == "__main__":
    run_derivative_daemon()
