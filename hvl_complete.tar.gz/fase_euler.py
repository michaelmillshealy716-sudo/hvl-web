# (c) 2026 HEALY VECTOR LABS. ALL RIGHTS RESERVED.
# Lead Architect: Michael Healy
# ==========================================================

import numpy as np
import time
import os
from datetime import datetime
import yfinance as yf
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import requests
import json

# ==========================================================
# SYSTEM ARCHITECTURE: FIREBASE REST ENDPOINT
# ==========================================================
FIREBASE_URL = "https://healy-vector-labs-default-rtdb.firebaseio.com/fase_telemetry.json"

class GeopoliticalBridge:
    def __init__(self):
        self.analyzer = SentimentIntensityAnalyzer()
        
    def get_intensity_scalar(self, raw_headline):
        if not raw_headline:
            return 0.0
        sentiment_dict = self.analyzer.polarity_scores(raw_headline)
        return sentiment_dict['compound']

class EdgarRaven:
    def __init__(self):
        print("[SYSTEM] Initializing Healy Vector Labs - FASE Data Pipeline")
        self.bridge = GeopoliticalBridge()
        
    def get_ticker_sentiment(self, ticker):
        print(f"[EDGAR] Tapping into live data feeds for {ticker}...")
        try:
            stock = yf.Ticker(ticker)
            news = stock.news
            if news:
                first_story = news[0]
                if isinstance(first_story, dict) and 'content' in first_story:
                    headline = first_story['content'].get('title', '')
                else:
                    headline = first_story.get('title', '')
                
                if headline:
                    print(f"[EDGAR] Live Headline Parsed: '{headline}'")
                    return headline
            return ""
        except Exception as e:
            print(f"[EDGAR] Connection timeout for {ticker}")
            return ""

class FASEStochasticEngine:
    def __init__(self, x0, T, dt):
        self.x0 = x0
        self.T = T
        self.dt = dt
        self.N = int(T / dt)
        self.t = np.linspace(0, self.T, self.N)
        
    def apply_agentic_sentiment(self, base_mu, sentiment_score):
        return base_mu + (sentiment_score * 0.5 * base_mu)
        
    def simulate_sentiment_path(self, base_mu, sigma, sentiment_score):
        mu_adj = self.apply_agentic_sentiment(base_mu, sentiment_score)
        dw = np.random.normal(0, np.sqrt(self.dt), self.N)
        W = np.cumsum(dw)
        S = self.x0 * np.exp((mu_adj - 0.5 * sigma**2) * self.t + sigma * W)
        return S

if __name__ == "__main__":
    tickers = ["TSLA", "F", "XOM", "PFE", "CL=F" ]
    N_sims = 1000
    
    base_prices = {
        "TSLA": 175.50,
        "F": 12.30,
        "XOM": 118.20,
        "PFE": 28.40,
        "CL=F": 82.10
    }
    
    print("[SYSTEM] Initializing FASE Pipeline for continuous Cloud deployment...")
    edgar = EdgarRaven()
    self_bridge = GeopoliticalBridge()
    
    try:
        while True:
            os.system('clear' if os.name == 'posix' else 'cls')
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            print(f"[SYSTEM] Commencing Execution Cycle: {current_time}")
            print("-" * 45)
            
            web_data = {
                "last_updated": current_time,
                "execution_id": time.time(),
                "projections": {}
            }
            
            for target_ticker in tickers:
                print("-" * 45)
                current_headline = edgar.get_ticker_sentiment(target_ticker)
                live_sentiment = self_bridge.get_intensity_scalar(current_headline)
                
                current_price = base_prices.get(target_ticker, 100.0)
                engine = FASEStochasticEngine(x0=current_price, T=1.0, dt=0.01)
                final_states = []
                
                print(f"[FASE] Running {N_sims}-path Monte Carlo on {target_ticker}...")
                for _ in range(N_sims):
                    path = engine.simulate_sentiment_path(base_mu=0.1, sigma=0.3, sentiment_score=live_sentiment)
                    final_states.append(path[-1])
                    
                expected_value = np.mean(final_states)
                ci_low, ci_high = np.percentile(final_states, [2.5, 97.5])
                rel_spread = (ci_high - ci_low) / expected_value
                
                web_data["projections"][target_ticker] = {
                    "expected_value": round(float(expected_value), 2),
                    "ci_low": round(float(ci_low), 2),
                    "ci_high": round(float(ci_high), 2),
                    "sentiment_score": round(float(live_sentiment), 3),
                    "headline": current_headline,
                    "volatility_alert": bool(rel_spread > 1.5)
                }

            # ==========================================
            # REST API INJECTION: OVERWRITE FIREBASE
            # ==========================================
            try:
                print(f"\n[SYSTEM] Executing PUT Request to Firebase RTDB...")
                headers = {'Content-Type': 'application/json'}
                res = requests.put(FIREBASE_URL, data=json.dumps(web_data), headers=headers, timeout=10)
                
                if res.status_code == 200:
                    print(f"[SYSTEM] 200 OK: State Reconciled. Sleeping 120s...")
                else:
                    print(f"[ERR] Sync Failure. Status: {res.status_code} - {res.text}")
                    
            except Exception as e:
                print(f"[ERR] REST Pipeline offline: {e}")

            time.sleep(120)

    except KeyboardInterrupt:
        print("\n\033[91m[ SYSTEM ] FASE ENGINE ARCHIVE LOCKED AND COLD STORED.\033[0m")
