import base64
import nacl.signing

# 1. Generate a secure cryptographic key pair
private_key = nacl.signing.SigningKey.generate()
public_key = private_key.verify_key

# 2. Convert them into clean base64 text strings
private_key_base64 = base64.b64encode(private_key.encode()).decode()
public_key_base64 = base64.b64encode(public_key.encode()).decode()

print("\n=== YOUR CRYPTO KEYS GENERATED ===")
print(f"PRIVATE KEY (Put this inside your secure .env file):\n{private_key_base64}\n")
print(f"PUBLIC KEY (Paste this into Robinhood's '+ Add Key' page):\n{public_key_base64}")
print("==================================")

