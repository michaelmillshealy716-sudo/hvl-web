import os
import time
import json
import numpy as np
from datetime import datetime, timedelta
from dotenv import load_dotenv
import robin_stocks.robinhood as r

# ---------------------------------------------------------
# 0. SECURE CREDENTIAL INGESTION & UI FORMATTING
# ---------------------------------------------------------
load_dotenv()
GREEN = '\033[92m'
RESET = '\033[0m'

def authenticate_node():
    print("[*SYSTEM] Initiating secure cryptographic handshake with Robinhood...")
    try:
        r.login(username=os.getenv("RH_USERNAME"), password=os.getenv("RH_PASSWORD"))
        print("[*SYSTEM] Authentication Verified. Live network active.")
    except Exception as e:
        print(f"[WARNING] API handshake issue: {e}")

# ---------------------------------------------------------
# 1. CORE MATH ENGINE (KINEMATICS + GALOIS LEARNING)
# ---------------------------------------------------------
class NeuroKinematics:
    def __init__(self, memory_window=60):
        self.window = memory_window
        self.timestamps = []
        self.prices = []
        self.velocities = []
        self.accelerations = [] # Added for self-learning history

    def ingest_crt_tick(self, raw_time, raw_price):
        quantized_time = round(raw_time * 10) / 10.0
        if not self.timestamps or quantized_time > self.timestamps[-1]:
            self.timestamps.append(quantized_time)
            self.prices.append(raw_price)
            if len(self.prices) > 1:
                dt = self.timestamps[-1] - self.timestamps[-2]
                v = (self.prices[-1] - self.prices[-2]) / dt if dt != 0 else 0
                self.velocities.append(v)
            else:
                self.velocities.append(0.0)
            
            # Enforce memory bounds
            if len(self.prices) > self.window:
                self.timestamps.pop(0)
                self.prices.pop(0)
                self.velocities.pop(0)

    def extract_fourier_derivatives(self):
        if len(self.velocities) < 5:
            return 0.0, 0.0
        v_current = self.velocities[-1]
        v_past = sum(self.velocities[-5:-1]) / 4.0
        dt = self.timestamps[-1] - self.timestamps[-5]
        acceleration = (v_current - v_past) / dt if dt != 0 else 0.0
        
        # Store a history for the self-learning Galois engine
        self.accelerations.append(acceleration)
        if len(self.accelerations) > self.window:
            self.accelerations.pop(0)
            
        return v_current, acceleration

    def project_taylor_series(self, dt_seconds):
        if len(self.prices) < 2:
            return self.prices[-1] if self.prices else 0.0
        
        x_now = self.prices[-1]
        v, a = self.extract_fourier_derivatives()
        
        dampening_ratio = 15.0 / max(dt_seconds, 15.0)
        dampened_a = a * dampening_ratio
        
        raw_projection = x_now + (v * dt_seconds) + (0.5 * dampened_a * (dt_seconds ** 2))
        
        # Dynamic Settlement Bound
        fraction_of_hour_left = min(dt_seconds / 3600.0, 1.0)
        max_allowed_move = x_now * (0.01 * fraction_of_hour_left)
        
        if raw_projection > x_now + max_allowed_move:
            return x_now + max_allowed_move
        elif raw_projection < x_now - max_allowed_move:
            return x_now - max_allowed_move
        return raw_projection

class AdaptiveGaloisEngine:
    def __init__(self):
        # The Formal Context Attributes
        self.attributes = ['HIGH_V_UP', 'POSITIVE_ACCEL', 'TAYLOR_PREMIUM']
        
    def check_lattice_lock(self, kinematics, current_price, projected_price):
        if len(kinematics.velocities) < 10:
            return False, "LEARNING_PHASE"
            
        # SELF-LEARNING: Calculate dynamic thresholds based on recent rolling history
        rolling_v_std = np.std(kinematics.velocities[-10:])
        current_v = kinematics.velocities[-1]
        current_a = kinematics.accelerations[-1] if kinematics.accelerations else 0.0
        
        # Binarize continuous data into the Galois Context Matrix
        is_high_v_up = 1 if current_v > (rolling_v_std * 1.2) else 0
        is_pos_accel = 1 if current_a > 0 else 0
        is_taylor_prem = 1 if projected_price > current_price else 0
        
        # Galois Derivation: If all attributes are present, the concept is locked
        if is_high_v_up and is_pos_accel and is_taylor_prem:
            return True, f"{GREEN}[BUY SIGNAL - GALOIS LATTICE LOCKED]{RESET}"
        else:
            return False, "[OBSERVING]"

# ---------------------------------------------------------
# 2. DAEMON LOOP (THE PRODUCER)
# ---------------------------------------------------------
def fetch_live_robinhood_spot():
    try:
        quote = r.crypto.get_crypto_quote('BTC')
        return time.time(), float(quote['mark_price'])
    except Exception:
        return time.time(), 0.0

def run_signal_daemon():
    authenticate_node()
    engine = NeuroKinematics(memory_window=60)
    galois = AdaptiveGaloisEngine()
    
    print("\n[*ALPHA NODE] Daemon initialized. Entering continuous 60-second heartbeat loop.")
    print("[*GALOIS NET] Self-learning matrices online. Waiting for data volume...\n")
    print(f"{'TIME':<12} | {'SPOT PRICE':<12} | {'FORECAST':<12} | {'STATUS':<15} | {'GALOIS STATE'}")
    print("-" * 75)
    
    while True:
        # 1. Ingest
        live_time, live_price = fetch_live_robinhood_spot()
        if live_price > 0:
            engine.ingest_crt_tick(live_time, live_price)
            
        # 2. Project
        exec_time = datetime.now()
        next_hour = (exec_time.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1))
        seconds_to_settlement = (next_hour - exec_time).total_seconds()
        
        projected_settlement = engine.project_taylor_series(seconds_to_settlement)
        memory_size = len(engine.prices)
        
        # 3. Evaluate Galois Grouping
        lock_achieved, galois_status = galois.check_lattice_lock(engine, live_price, projected_settlement)
        
        # 4. Print Radar Blip
        status = "WARMUP" if memory_size < 5 else "LOCKED"
        
        # Format the output row
        row = f"{exec_time.strftime('%H:%M:%S'):<12} | ${live_price:<11.2f} | ${projected_settlement:<11.2f} | {memory_size}/60 {status:<8} | {galois_status}"
        print(row)
        
        # 5. Export JSON Payload
        if status == "LOCKED":
            signal_data = {
                "timestamp": exec_time.strftime('%Y-%m-%d %H:%M:%S'),
                "current_spot": live_price,
                "projected_settlement": projected_settlement,
                "seconds_to_settlement": seconds_to_settlement,
                "status": "VALID",
                "galois_lock": lock_achieved
            }
            with open("target_signal.json", "w") as f:
                json.dump(signal_data, f, indent=4)
                
        # 6. Sleep until next heartbeat
        time.sleep(60.0)

if __name__ == "__main__":
    run_signal_daemon()

